package org.jfree.chart.event;


public interface AnnotationChangeListener extends java.util.EventListener {
	public void annotationChanged(org.jfree.chart.event.AnnotationChangeEvent event);
}

