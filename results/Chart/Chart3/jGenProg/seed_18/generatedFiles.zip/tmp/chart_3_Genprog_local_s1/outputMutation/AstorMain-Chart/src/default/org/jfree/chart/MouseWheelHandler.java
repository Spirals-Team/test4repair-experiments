package org.jfree.chart;


class MouseWheelHandler implements java.awt.event.MouseWheelListener , java.io.Serializable {
	private org.jfree.chart.ChartPanel chartPanel;

	double zoomFactor;

	public MouseWheelHandler(org.jfree.chart.ChartPanel chartPanel) {
		org.jfree.chart.MouseWheelHandler.this.chartPanel = chartPanel;
		org.jfree.chart.MouseWheelHandler.this.zoomFactor = 0.1;
		org.jfree.chart.MouseWheelHandler.this.chartPanel.addMouseWheelListener(org.jfree.chart.MouseWheelHandler.this);
	}

	public double getZoomFactor() {
		return org.jfree.chart.MouseWheelHandler.this.zoomFactor;
	}

	public void setZoomFactor(double zoomFactor) {
		org.jfree.chart.MouseWheelHandler.this.zoomFactor = zoomFactor;
	}

	public void mouseWheelMoved(java.awt.event.MouseWheelEvent e) {
		org.jfree.chart.JFreeChart chart = org.jfree.chart.MouseWheelHandler.this.chartPanel.getChart();
		if (chart == null) {
			return ;
		} 
		org.jfree.chart.plot.Plot plot = chart.getPlot();
		if (plot instanceof org.jfree.chart.plot.Zoomable) {
			org.jfree.chart.plot.Zoomable zoomable = ((org.jfree.chart.plot.Zoomable)(plot));
			handleZoomable(zoomable, e);
		} 
	}

	private void handleZoomable(org.jfree.chart.plot.Zoomable zoomable, java.awt.event.MouseWheelEvent e) {
		org.jfree.chart.plot.Plot plot = ((org.jfree.chart.plot.Plot)(zoomable));
		org.jfree.chart.ChartRenderingInfo info = org.jfree.chart.MouseWheelHandler.this.chartPanel.getChartRenderingInfo();
		org.jfree.chart.plot.PlotRenderingInfo pinfo = info.getPlotInfo();
		java.awt.geom.Point2D p = org.jfree.chart.MouseWheelHandler.this.chartPanel.translateScreenToJava2D(e.getPoint());
		if (!(pinfo.getDataArea().contains(p))) {
			return ;
		} 
		int clicks = e.getWheelRotation();
		int direction = 0;
		if (clicks < 0) {
			direction = -1;
		} else if (clicks > 0) {
			direction = 1;
		} 
		boolean old = plot.isNotify();
		plot.setNotify(false);
		double increment = 1.0 + (org.jfree.chart.MouseWheelHandler.this.zoomFactor);
		if (direction > 0) {
			zoomable.zoomDomainAxes(increment, pinfo, p, true);
			zoomable.zoomRangeAxes(increment, pinfo, p, true);
		} else if (direction < 0) {
			zoomable.zoomDomainAxes((1.0 / increment), pinfo, p, true);
			zoomable.zoomRangeAxes((1.0 / increment), pinfo, p, true);
		} 
		plot.setNotify(old);
	}
}

