package org.jfree.chart.imagemap;


public interface ToolTipTagFragmentGenerator {
	public java.lang.String generateToolTipFragment(java.lang.String toolTipText);
}

