package org.jfree.chart.annotations;


public interface Annotation {
	public void addChangeListener(org.jfree.chart.event.AnnotationChangeListener listener);

	public void removeChangeListener(org.jfree.chart.event.AnnotationChangeListener listener);
}

