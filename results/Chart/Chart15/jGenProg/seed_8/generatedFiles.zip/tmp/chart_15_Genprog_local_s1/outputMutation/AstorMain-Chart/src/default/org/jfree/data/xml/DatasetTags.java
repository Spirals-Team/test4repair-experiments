package org.jfree.data.xml;


public interface DatasetTags {
	public static final java.lang.String PIEDATASET_TAG = "PieDataset";

	public static final java.lang.String CATEGORYDATASET_TAG = "CategoryDataset";

	public static final java.lang.String SERIES_TAG = "Series";

	public static final java.lang.String ITEM_TAG = "Item";

	public static final java.lang.String KEY_TAG = "Key";

	public static final java.lang.String VALUE_TAG = "Value";
}

