package org.jfree.data;


public class UnknownKeyException extends java.lang.IllegalArgumentException {
	public UnknownKeyException(java.lang.String message) {
		super(message);
	}
}

