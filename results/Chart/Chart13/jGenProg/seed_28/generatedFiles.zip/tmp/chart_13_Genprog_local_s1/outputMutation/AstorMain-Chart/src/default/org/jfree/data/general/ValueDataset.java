package org.jfree.data.general;


public interface ValueDataset extends org.jfree.data.Value , org.jfree.data.general.Dataset {}

