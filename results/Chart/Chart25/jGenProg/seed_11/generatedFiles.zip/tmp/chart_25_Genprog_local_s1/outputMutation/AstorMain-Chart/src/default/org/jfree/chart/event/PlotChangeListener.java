package org.jfree.chart.event;


public interface PlotChangeListener extends java.util.EventListener {
	public void plotChanged(org.jfree.chart.event.PlotChangeEvent event);
}

