package org.jfree.chart;


public interface Drawable {
	public void draw(java.awt.Graphics2D g2, java.awt.geom.Rectangle2D area);
}

