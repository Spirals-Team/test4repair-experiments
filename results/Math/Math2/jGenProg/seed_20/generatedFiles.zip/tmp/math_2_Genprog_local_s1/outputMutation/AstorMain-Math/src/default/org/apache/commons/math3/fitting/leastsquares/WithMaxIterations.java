package org.apache.commons.math3.fitting.leastsquares;


public interface WithMaxIterations<T> {
	T withMaxIterations(int maxIter);
}

