package org.apache.commons.math3.optim;


public interface OptimizationData {}

