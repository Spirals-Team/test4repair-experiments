package org.apache.commons.math3.geometry.euclidean.threed;


public class NotARotationMatrixException extends org.apache.commons.math3.exception.MathIllegalArgumentException {
	private static final long serialVersionUID = 5647178478658937642L;

	public NotARotationMatrixException(org.apache.commons.math3.exception.util.Localizable specifier ,java.lang.Object... parts) {
		super(specifier, parts);
	}
}

