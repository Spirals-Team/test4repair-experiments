package org.apache.commons.math3.fitting.leastsquares;


public abstract class AbstractLeastSquaresOptimizer<OPTIM extends org.apache.commons.math3.fitting.leastsquares.AbstractLeastSquaresOptimizer<OPTIM>> extends org.apache.commons.math3.optim.AbstractOptimizer<org.apache.commons.math3.optim.PointVectorValuePair, OPTIM> implements org.apache.commons.math3.fitting.leastsquares.WithModelAndJacobian<OPTIM> , org.apache.commons.math3.fitting.leastsquares.WithStartPoint<OPTIM> , org.apache.commons.math3.fitting.leastsquares.WithTarget<OPTIM> , org.apache.commons.math3.fitting.leastsquares.WithWeight<OPTIM> {
	private double[] target;

	private org.apache.commons.math3.linear.RealMatrix weight;

	private org.apache.commons.math3.analysis.MultivariateVectorFunction model;

	private org.apache.commons.math3.analysis.MultivariateMatrixFunction jacobian;

	private org.apache.commons.math3.linear.RealMatrix weightSqrt;

	private double[] start;

	protected AbstractLeastSquaresOptimizer() {
	}

	protected AbstractLeastSquaresOptimizer(org.apache.commons.math3.fitting.leastsquares.AbstractLeastSquaresOptimizer other) {
		target = (other.target) == null ? null : other.target.clone();
		start = (other.start) == null ? null : other.start.clone();
		weight = (other.weight) == null ? null : other.weight.copy();
		weightSqrt = (other.weightSqrt) == null ? null : other.weightSqrt.copy();
		model = other.model;
		jacobian = other.jacobian;
	}

	public OPTIM withTarget(double[] target) {
		org.apache.commons.math3.fitting.leastsquares.AbstractLeastSquaresOptimizer.this.target = target.clone();
		return self();
	}

	public OPTIM withWeight(org.apache.commons.math3.linear.RealMatrix weight) {
		org.apache.commons.math3.fitting.leastsquares.AbstractLeastSquaresOptimizer.this.weight = weight;
		weightSqrt = squareRoot(weight);
		return self();
	}

	public OPTIM withModelAndJacobian(org.apache.commons.math3.analysis.MultivariateVectorFunction model, org.apache.commons.math3.analysis.MultivariateMatrixFunction jacobian) {
		org.apache.commons.math3.fitting.leastsquares.AbstractLeastSquaresOptimizer.this.model = model;
		org.apache.commons.math3.fitting.leastsquares.AbstractLeastSquaresOptimizer.this.jacobian = jacobian;
		return self();
	}

	public OPTIM withStartPoint(double[] start) {
		org.apache.commons.math3.fitting.leastsquares.AbstractLeastSquaresOptimizer.this.start = start.clone();
		return self();
	}

	public double[] getTarget() {
		return (target) == null ? null : target.clone();
	}

	public double[] getStart() {
		return (start) == null ? null : start.clone();
	}

	public org.apache.commons.math3.linear.RealMatrix getWeightSquareRoot() {
		return (weightSqrt) == null ? null : weightSqrt.copy();
	}

	public org.apache.commons.math3.analysis.MultivariateVectorFunction getModel() {
		return model;
	}

	public org.apache.commons.math3.analysis.MultivariateMatrixFunction getJacobian() {
		return jacobian;
	}

	public double[][] computeCovariances(double[] params, double threshold) {
		final org.apache.commons.math3.linear.RealMatrix j = computeWeightedJacobian(params);
		final org.apache.commons.math3.linear.RealMatrix jTj = j.transpose().multiply(j);
		final org.apache.commons.math3.linear.DecompositionSolver solver = new org.apache.commons.math3.linear.QRDecomposition(jTj , threshold).getSolver();
		return solver.getInverse().getData();
	}

	public double[] computeSigma(double[] params, double covarianceSingularityThreshold) {
		final int nC = params.length;
		final double[] sig = new double[nC];
		final double[][] cov = computeCovariances(params, covarianceSingularityThreshold);
		for (int i = 0 ; i < nC ; ++i) {
			sig[i] = org.apache.commons.math3.util.FastMath.sqrt(cov[i][i]);
		}
		return sig;
	}

	public org.apache.commons.math3.linear.RealMatrix getWeight() {
		return weight.copy();
	}

	public double computeRMS(double[] params) {
		final double cost = computeCost(computeResiduals(getModel().value(params)));
		return org.apache.commons.math3.util.FastMath.sqrt(((cost * cost) / (target.length)));
	}

	protected double[] computeObjectiveValue(double[] params) {
		super.incrementEvaluationCount();
		return model.value(params);
	}

	protected org.apache.commons.math3.linear.RealMatrix computeWeightedJacobian(double[] params) {
		return weightSqrt.multiply(org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(computeJacobian(params)));
	}

	protected double[][] computeJacobian(final double[] params) {
		return jacobian.value(params);
	}

	protected double computeCost(double[] residuals) {
		final org.apache.commons.math3.linear.ArrayRealVector r = new org.apache.commons.math3.linear.ArrayRealVector(residuals);
		return org.apache.commons.math3.util.FastMath.sqrt(r.dotProduct(weight.operate(r)));
	}

	protected double[] computeResiduals(double[] objectiveValue) {
		if ((objectiveValue.length) != (target.length)) {
			throw new org.apache.commons.math3.exception.DimensionMismatchException(target.length , objectiveValue.length);
		} 
		final double[] residuals = new double[target.length];
		for (int i = 0 ; i < (target.length) ; i++) {
			residuals[i] = (target[i]) - (objectiveValue[i]);
		}
		return residuals;
	}

	private org.apache.commons.math3.linear.RealMatrix squareRoot(org.apache.commons.math3.linear.RealMatrix m) {
		if (m instanceof org.apache.commons.math3.linear.DiagonalMatrix) {
			final int dim = m.getRowDimension();
			final org.apache.commons.math3.linear.RealMatrix sqrtM = new org.apache.commons.math3.linear.DiagonalMatrix(dim);
			for (int i = 0 ; i < dim ; i++) {
				sqrtM.setEntry(i, i, org.apache.commons.math3.util.FastMath.sqrt(m.getEntry(i, i)));
			}
			return sqrtM;
		} else {
			final org.apache.commons.math3.linear.EigenDecomposition dec = new org.apache.commons.math3.linear.EigenDecomposition(m);
			return dec.getSquareRoot();
		}
	}
}

