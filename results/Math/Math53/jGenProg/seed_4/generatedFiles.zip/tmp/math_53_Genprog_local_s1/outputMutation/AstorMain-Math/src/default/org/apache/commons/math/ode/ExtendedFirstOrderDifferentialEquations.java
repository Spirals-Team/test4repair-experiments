package org.apache.commons.math.ode;


public interface ExtendedFirstOrderDifferentialEquations extends org.apache.commons.math.ode.FirstOrderDifferentialEquations {
	int getMainSetDimension();
}

