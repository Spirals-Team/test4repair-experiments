package org.apache.commons.math.genetics;


public interface PermutationChromosome<T> {
	java.util.List<T> decode(java.util.List<T> sequence);
}

