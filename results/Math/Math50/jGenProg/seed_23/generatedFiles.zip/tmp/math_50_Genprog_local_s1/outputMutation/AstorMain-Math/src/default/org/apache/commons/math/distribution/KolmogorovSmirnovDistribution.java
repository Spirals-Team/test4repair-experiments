package org.apache.commons.math.distribution;


public interface KolmogorovSmirnovDistribution {
	double cdf(double d);
}

