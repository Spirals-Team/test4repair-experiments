package org.apache.commons.math.optimization;


public interface MultivariateRealOptimizer extends org.apache.commons.math.optimization.BaseMultivariateRealOptimizer<org.apache.commons.math.analysis.MultivariateFunction> {}

