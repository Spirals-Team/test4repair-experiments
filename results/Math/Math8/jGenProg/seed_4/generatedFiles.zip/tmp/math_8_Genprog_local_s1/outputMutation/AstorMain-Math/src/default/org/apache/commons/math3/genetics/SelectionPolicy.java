package org.apache.commons.math3.genetics;


public interface SelectionPolicy {
	org.apache.commons.math3.genetics.ChromosomePair select(org.apache.commons.math3.genetics.Population population) throws org.apache.commons.math3.exception.MathIllegalArgumentException;
}

