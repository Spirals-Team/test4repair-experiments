package org.apache.commons.math.distribution;


public interface TDistribution extends org.apache.commons.math.distribution.ContinuousDistribution {
	@java.lang.Deprecated
	void setDegreesOfFreedom(double degreesOfFreedom);

	double getDegreesOfFreedom();
}

