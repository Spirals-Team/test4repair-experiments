package org.apache.commons.math.optimization;


public enum GoalType implements java.io.Serializable {
MAXIMIZE, MINIMIZE;}

