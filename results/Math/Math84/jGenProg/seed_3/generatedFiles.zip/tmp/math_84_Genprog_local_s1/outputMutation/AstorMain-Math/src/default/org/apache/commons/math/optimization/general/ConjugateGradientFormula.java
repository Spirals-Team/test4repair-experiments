package org.apache.commons.math.optimization.general;


public enum ConjugateGradientFormula {
FLETCHER_REEVES, POLAK_RIBIERE;}

