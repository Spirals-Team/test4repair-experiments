package org.joda.time.convert;


public interface Converter {
	java.lang.Class<?> getSupportedType();
}

