package org.joda.time;


public class JodaTimePermission extends java.security.BasicPermission {
	private static final long serialVersionUID = 1408944367355875472L;

	public JodaTimePermission(java.lang.String name) {
		super(name);
	}
}

