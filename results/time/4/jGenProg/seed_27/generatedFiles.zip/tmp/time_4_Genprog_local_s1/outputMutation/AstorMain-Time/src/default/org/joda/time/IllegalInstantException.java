package org.joda.time;


public class IllegalInstantException extends java.lang.IllegalArgumentException {
	private static final long serialVersionUID = 2858712538216L;

	public IllegalInstantException(java.lang.String message) {
		super(message);
	}

	public IllegalInstantException(long instantLocal ,java.lang.String zoneId) {
		super(org.joda.time.IllegalInstantException.createMessage(instantLocal, zoneId));
	}

	private static java.lang.String createMessage(long instantLocal, java.lang.String zoneId) {
		java.lang.String localDateTime = org.joda.time.format.DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS").print(new org.joda.time.Instant(instantLocal));
		java.lang.String zone = zoneId != null ? (" (" + zoneId) + ")" : "";
		return ("Illegal instant due to time zone offset transition (daylight savings time 'gap'): " + localDateTime) + zone;
	}

	public static boolean isIllegalInstant(java.lang.Throwable ex) {
		if (ex instanceof org.joda.time.IllegalInstantException) {
			return true;
		} 
		while (((ex.getCause()) != null) && ((ex.getCause()) != ex)) {
			return org.joda.time.IllegalInstantException.isIllegalInstant(ex.getCause());
		}
		return false;
	}
}

