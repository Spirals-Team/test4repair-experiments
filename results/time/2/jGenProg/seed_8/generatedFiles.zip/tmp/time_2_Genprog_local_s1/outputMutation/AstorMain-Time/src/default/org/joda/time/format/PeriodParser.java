package org.joda.time.format;


public interface PeriodParser {
	int parseInto(org.joda.time.ReadWritablePeriod period, java.lang.String periodStr, int position, java.util.Locale locale);
}

