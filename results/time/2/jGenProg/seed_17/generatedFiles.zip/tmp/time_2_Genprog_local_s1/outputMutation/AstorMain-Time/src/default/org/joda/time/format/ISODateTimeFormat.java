package org.joda.time.format;


public class ISODateTimeFormat {
	protected ISODateTimeFormat() {
		super();
	}

	public static org.joda.time.format.DateTimeFormatter forFields(java.util.Collection<org.joda.time.DateTimeFieldType> fields, boolean extended, boolean strictISO) {
		if ((fields == null) || ((fields.size()) == 0)) {
			throw new java.lang.IllegalArgumentException("The fields must not be null or empty");
		} 
		java.util.Set<org.joda.time.DateTimeFieldType> workingFields = new java.util.HashSet<org.joda.time.DateTimeFieldType>(fields);
		int inputSize = workingFields.size();
		boolean reducedPrec = false;
		org.joda.time.format.DateTimeFormatterBuilder bld = new org.joda.time.format.DateTimeFormatterBuilder();
		if (workingFields.contains(org.joda.time.DateTimeFieldType.monthOfYear())) {
			reducedPrec = org.joda.time.format.ISODateTimeFormat.dateByMonth(bld, workingFields, extended, strictISO);
		} else if (workingFields.contains(org.joda.time.DateTimeFieldType.dayOfYear())) {
			reducedPrec = org.joda.time.format.ISODateTimeFormat.dateByOrdinal(bld, workingFields, extended, strictISO);
		} else if (workingFields.contains(org.joda.time.DateTimeFieldType.weekOfWeekyear())) {
			reducedPrec = org.joda.time.format.ISODateTimeFormat.dateByWeek(bld, workingFields, extended, strictISO);
		} else if (workingFields.contains(org.joda.time.DateTimeFieldType.dayOfMonth())) {
			reducedPrec = org.joda.time.format.ISODateTimeFormat.dateByMonth(bld, workingFields, extended, strictISO);
		} else if (workingFields.contains(org.joda.time.DateTimeFieldType.dayOfWeek())) {
			reducedPrec = org.joda.time.format.ISODateTimeFormat.dateByWeek(bld, workingFields, extended, strictISO);
		} else if (workingFields.remove(org.joda.time.DateTimeFieldType.year())) {
			bld.append(org.joda.time.format.ISODateTimeFormat.Constants.ye);
			reducedPrec = true;
		} else if (workingFields.remove(org.joda.time.DateTimeFieldType.weekyear())) {
			bld.append(org.joda.time.format.ISODateTimeFormat.Constants.we);
			reducedPrec = true;
		} 
		boolean datePresent = (workingFields.size()) < inputSize;
		org.joda.time.format.ISODateTimeFormat.time(bld, workingFields, extended, strictISO, reducedPrec, datePresent);
		if ((bld.canBuildFormatter()) == false) {
			throw new java.lang.IllegalArgumentException(("No valid format for fields: " + fields));
		} 
		try {
			fields.retainAll(workingFields);
		} catch (java.lang.UnsupportedOperationException ex) {
		}
		return bld.toFormatter();
	}

	private static boolean dateByMonth(org.joda.time.format.DateTimeFormatterBuilder bld, java.util.Collection<org.joda.time.DateTimeFieldType> fields, boolean extended, boolean strictISO) {
		boolean reducedPrec = false;
		if (fields.remove(org.joda.time.DateTimeFieldType.year())) {
			bld.append(org.joda.time.format.ISODateTimeFormat.Constants.ye);
			if (fields.remove(org.joda.time.DateTimeFieldType.monthOfYear())) {
				if (fields.remove(org.joda.time.DateTimeFieldType.dayOfMonth())) {
					org.joda.time.format.ISODateTimeFormat.appendSeparator(bld, extended);
					bld.appendMonthOfYear(2);
					org.joda.time.format.ISODateTimeFormat.appendSeparator(bld, extended);
					bld.appendDayOfMonth(2);
				} else {
					bld.appendLiteral('-');
					bld.appendMonthOfYear(2);
					reducedPrec = true;
				}
			} else {
				if (fields.remove(org.joda.time.DateTimeFieldType.dayOfMonth())) {
					org.joda.time.format.ISODateTimeFormat.checkNotStrictISO(fields, strictISO);
					bld.appendLiteral('-');
					bld.appendLiteral('-');
					bld.appendDayOfMonth(2);
				} else {
					reducedPrec = true;
				}
			}
		} else if (fields.remove(org.joda.time.DateTimeFieldType.monthOfYear())) {
			bld.appendLiteral('-');
			bld.appendLiteral('-');
			bld.appendMonthOfYear(2);
			if (fields.remove(org.joda.time.DateTimeFieldType.dayOfMonth())) {
				org.joda.time.format.ISODateTimeFormat.appendSeparator(bld, extended);
				bld.appendDayOfMonth(2);
			} else {
				reducedPrec = true;
			}
		} else if (fields.remove(org.joda.time.DateTimeFieldType.dayOfMonth())) {
			bld.appendLiteral('-');
			bld.appendLiteral('-');
			bld.appendLiteral('-');
			bld.appendDayOfMonth(2);
		} 
		return reducedPrec;
	}

	private static boolean dateByOrdinal(org.joda.time.format.DateTimeFormatterBuilder bld, java.util.Collection<org.joda.time.DateTimeFieldType> fields, boolean extended, boolean strictISO) {
		boolean reducedPrec = false;
		if (fields.remove(org.joda.time.DateTimeFieldType.year())) {
			bld.append(org.joda.time.format.ISODateTimeFormat.Constants.ye);
			if (fields.remove(org.joda.time.DateTimeFieldType.dayOfYear())) {
				org.joda.time.format.ISODateTimeFormat.appendSeparator(bld, extended);
				bld.appendDayOfYear(3);
			} else {
				reducedPrec = true;
			}
		} else if (fields.remove(org.joda.time.DateTimeFieldType.dayOfYear())) {
			bld.appendLiteral('-');
			bld.appendDayOfYear(3);
		} 
		return reducedPrec;
	}

	private static boolean dateByWeek(org.joda.time.format.DateTimeFormatterBuilder bld, java.util.Collection<org.joda.time.DateTimeFieldType> fields, boolean extended, boolean strictISO) {
		boolean reducedPrec = false;
		if (fields.remove(org.joda.time.DateTimeFieldType.weekyear())) {
			bld.append(org.joda.time.format.ISODateTimeFormat.Constants.we);
			if (fields.remove(org.joda.time.DateTimeFieldType.weekOfWeekyear())) {
				org.joda.time.format.ISODateTimeFormat.appendSeparator(bld, extended);
				bld.appendLiteral('W');
				bld.appendWeekOfWeekyear(2);
				if (fields.remove(org.joda.time.DateTimeFieldType.dayOfWeek())) {
					org.joda.time.format.ISODateTimeFormat.appendSeparator(bld, extended);
					bld.appendDayOfWeek(1);
				} else {
					reducedPrec = true;
				}
			} else {
				if (fields.remove(org.joda.time.DateTimeFieldType.dayOfWeek())) {
					org.joda.time.format.ISODateTimeFormat.checkNotStrictISO(fields, strictISO);
					org.joda.time.format.ISODateTimeFormat.appendSeparator(bld, extended);
					bld.appendLiteral('W');
					bld.appendLiteral('-');
					bld.appendDayOfWeek(1);
				} else {
					reducedPrec = true;
				}
			}
		} else if (fields.remove(org.joda.time.DateTimeFieldType.weekOfWeekyear())) {
			bld.appendLiteral('-');
			bld.appendLiteral('W');
			bld.appendWeekOfWeekyear(2);
			if (fields.remove(org.joda.time.DateTimeFieldType.dayOfWeek())) {
				org.joda.time.format.ISODateTimeFormat.appendSeparator(bld, extended);
				bld.appendDayOfWeek(1);
			} else {
				reducedPrec = true;
			}
		} else if (fields.remove(org.joda.time.DateTimeFieldType.dayOfWeek())) {
			bld.appendLiteral('-');
			bld.appendLiteral('W');
			bld.appendLiteral('-');
			bld.appendDayOfWeek(1);
		} 
		return reducedPrec;
	}

	private static void time(org.joda.time.format.DateTimeFormatterBuilder bld, java.util.Collection<org.joda.time.DateTimeFieldType> fields, boolean extended, boolean strictISO, boolean reducedPrec, boolean datePresent) {
		boolean hour = fields.remove(org.joda.time.DateTimeFieldType.hourOfDay());
		boolean minute = fields.remove(org.joda.time.DateTimeFieldType.minuteOfHour());
		boolean second = fields.remove(org.joda.time.DateTimeFieldType.secondOfMinute());
		boolean milli = fields.remove(org.joda.time.DateTimeFieldType.millisOfSecond());
		if ((((!hour) && (!minute)) && (!second)) && (!milli)) {
			return ;
		} 
		if (((hour || minute) || second) || milli) {
			if (strictISO && reducedPrec) {
				throw new java.lang.IllegalArgumentException(("No valid ISO8601 format for fields because Date was reduced precision: " + fields));
			} 
			if (datePresent) {
				bld.appendLiteral('T');
			} 
		} 
		if (((hour && minute) && second) || ((hour && (!second)) && (!milli))) {
		} else {
			if (strictISO && datePresent) {
				throw new java.lang.IllegalArgumentException(("No valid ISO8601 format for fields because Time was truncated: " + fields));
			} 
			if ((!hour) && (((minute && second) || (minute && (!milli))) || second)) {
			} else {
				if (strictISO) {
					throw new java.lang.IllegalArgumentException(("No valid ISO8601 format for fields: " + fields));
				} 
			}
		}
		if (hour) {
			bld.appendHourOfDay(2);
		} else if ((minute || second) || milli) {
			bld.appendLiteral('-');
		} 
		if ((extended && hour) && minute) {
			bld.appendLiteral(':');
		} 
		if (minute) {
			bld.appendMinuteOfHour(2);
		} else if (second || milli) {
			bld.appendLiteral('-');
		} 
		if ((extended && minute) && second) {
			bld.appendLiteral(':');
		} 
		if (second) {
			bld.appendSecondOfMinute(2);
		} else if (milli) {
			bld.appendLiteral('-');
		} 
		if (milli) {
			bld.appendLiteral('.');
			bld.appendMillisOfSecond(3);
		} 
	}

	private static void checkNotStrictISO(java.util.Collection<org.joda.time.DateTimeFieldType> fields, boolean strictISO) {
		if (strictISO) {
			throw new java.lang.IllegalArgumentException(("No valid ISO8601 format for fields: " + fields));
		} 
	}

	private static void appendSeparator(org.joda.time.format.DateTimeFormatterBuilder bld, boolean extended) {
		if (extended) {
			bld.appendLiteral('-');
		} 
	}

	public static org.joda.time.format.DateTimeFormatter dateParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dp;
	}

	public static org.joda.time.format.DateTimeFormatter localDateParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.ldp;
	}

	public static org.joda.time.format.DateTimeFormatter dateElementParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dpe;
	}

	public static org.joda.time.format.DateTimeFormatter timeParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.tp;
	}

	public static org.joda.time.format.DateTimeFormatter localTimeParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.ltp;
	}

	public static org.joda.time.format.DateTimeFormatter timeElementParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.tpe;
	}

	public static org.joda.time.format.DateTimeFormatter dateTimeParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dtp;
	}

	public static org.joda.time.format.DateTimeFormatter dateOptionalTimeParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dotp;
	}

	public static org.joda.time.format.DateTimeFormatter localDateOptionalTimeParser() {
		return org.joda.time.format.ISODateTimeFormat.Constants.ldotp;
	}

	public static org.joda.time.format.DateTimeFormatter date() {
		return org.joda.time.format.ISODateTimeFormat.yearMonthDay();
	}

	public static org.joda.time.format.DateTimeFormatter time() {
		return org.joda.time.format.ISODateTimeFormat.Constants.t;
	}

	public static org.joda.time.format.DateTimeFormatter timeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.tx;
	}

	public static org.joda.time.format.DateTimeFormatter tTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.tt;
	}

	public static org.joda.time.format.DateTimeFormatter tTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.ttx;
	}

	public static org.joda.time.format.DateTimeFormatter dateTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dt;
	}

	public static org.joda.time.format.DateTimeFormatter dateTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dtx;
	}

	public static org.joda.time.format.DateTimeFormatter ordinalDate() {
		return org.joda.time.format.ISODateTimeFormat.Constants.od;
	}

	public static org.joda.time.format.DateTimeFormatter ordinalDateTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.odt;
	}

	public static org.joda.time.format.DateTimeFormatter ordinalDateTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.odtx;
	}

	public static org.joda.time.format.DateTimeFormatter weekDate() {
		return org.joda.time.format.ISODateTimeFormat.Constants.wwd;
	}

	public static org.joda.time.format.DateTimeFormatter weekDateTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.wdt;
	}

	public static org.joda.time.format.DateTimeFormatter weekDateTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.wdtx;
	}

	public static org.joda.time.format.DateTimeFormatter basicDate() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bd;
	}

	public static org.joda.time.format.DateTimeFormatter basicTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bt;
	}

	public static org.joda.time.format.DateTimeFormatter basicTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.btx;
	}

	public static org.joda.time.format.DateTimeFormatter basicTTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.btt;
	}

	public static org.joda.time.format.DateTimeFormatter basicTTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bttx;
	}

	public static org.joda.time.format.DateTimeFormatter basicDateTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bdt;
	}

	public static org.joda.time.format.DateTimeFormatter basicDateTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bdtx;
	}

	public static org.joda.time.format.DateTimeFormatter basicOrdinalDate() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bod;
	}

	public static org.joda.time.format.DateTimeFormatter basicOrdinalDateTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bodt;
	}

	public static org.joda.time.format.DateTimeFormatter basicOrdinalDateTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bodtx;
	}

	public static org.joda.time.format.DateTimeFormatter basicWeekDate() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bwd;
	}

	public static org.joda.time.format.DateTimeFormatter basicWeekDateTime() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bwdt;
	}

	public static org.joda.time.format.DateTimeFormatter basicWeekDateTimeNoMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.bwdtx;
	}

	public static org.joda.time.format.DateTimeFormatter year() {
		return org.joda.time.format.ISODateTimeFormat.Constants.ye;
	}

	public static org.joda.time.format.DateTimeFormatter yearMonth() {
		return org.joda.time.format.ISODateTimeFormat.Constants.ym;
	}

	public static org.joda.time.format.DateTimeFormatter yearMonthDay() {
		return org.joda.time.format.ISODateTimeFormat.Constants.ymd;
	}

	public static org.joda.time.format.DateTimeFormatter weekyear() {
		return org.joda.time.format.ISODateTimeFormat.Constants.we;
	}

	public static org.joda.time.format.DateTimeFormatter weekyearWeek() {
		return org.joda.time.format.ISODateTimeFormat.Constants.ww;
	}

	public static org.joda.time.format.DateTimeFormatter weekyearWeekDay() {
		return org.joda.time.format.ISODateTimeFormat.Constants.wwd;
	}

	public static org.joda.time.format.DateTimeFormatter hour() {
		return org.joda.time.format.ISODateTimeFormat.Constants.hde;
	}

	public static org.joda.time.format.DateTimeFormatter hourMinute() {
		return org.joda.time.format.ISODateTimeFormat.Constants.hm;
	}

	public static org.joda.time.format.DateTimeFormatter hourMinuteSecond() {
		return org.joda.time.format.ISODateTimeFormat.Constants.hms;
	}

	public static org.joda.time.format.DateTimeFormatter hourMinuteSecondMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.hmsl;
	}

	public static org.joda.time.format.DateTimeFormatter hourMinuteSecondFraction() {
		return org.joda.time.format.ISODateTimeFormat.Constants.hmsf;
	}

	public static org.joda.time.format.DateTimeFormatter dateHour() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dh;
	}

	public static org.joda.time.format.DateTimeFormatter dateHourMinute() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dhm;
	}

	public static org.joda.time.format.DateTimeFormatter dateHourMinuteSecond() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dhms;
	}

	public static org.joda.time.format.DateTimeFormatter dateHourMinuteSecondMillis() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dhmsl;
	}

	public static org.joda.time.format.DateTimeFormatter dateHourMinuteSecondFraction() {
		return org.joda.time.format.ISODateTimeFormat.Constants.dhmsf;
	}

	static final class Constants {
		private static final org.joda.time.format.DateTimeFormatter ye = org.joda.time.format.ISODateTimeFormat.Constants.yearElement();

		private static final org.joda.time.format.DateTimeFormatter mye = org.joda.time.format.ISODateTimeFormat.Constants.monthElement();

		private static final org.joda.time.format.DateTimeFormatter dme = org.joda.time.format.ISODateTimeFormat.Constants.dayOfMonthElement();

		private static final org.joda.time.format.DateTimeFormatter we = org.joda.time.format.ISODateTimeFormat.Constants.weekyearElement();

		private static final org.joda.time.format.DateTimeFormatter wwe = org.joda.time.format.ISODateTimeFormat.Constants.weekElement();

		private static final org.joda.time.format.DateTimeFormatter dwe = org.joda.time.format.ISODateTimeFormat.Constants.dayOfWeekElement();

		private static final org.joda.time.format.DateTimeFormatter dye = org.joda.time.format.ISODateTimeFormat.Constants.dayOfYearElement();

		private static final org.joda.time.format.DateTimeFormatter hde = org.joda.time.format.ISODateTimeFormat.Constants.hourElement();

		private static final org.joda.time.format.DateTimeFormatter mhe = org.joda.time.format.ISODateTimeFormat.Constants.minuteElement();

		private static final org.joda.time.format.DateTimeFormatter sme = org.joda.time.format.ISODateTimeFormat.Constants.secondElement();

		private static final org.joda.time.format.DateTimeFormatter fse = org.joda.time.format.ISODateTimeFormat.Constants.fractionElement();

		private static final org.joda.time.format.DateTimeFormatter ze = org.joda.time.format.ISODateTimeFormat.Constants.offsetElement();

		private static final org.joda.time.format.DateTimeFormatter lte = org.joda.time.format.ISODateTimeFormat.Constants.literalTElement();

		private static final org.joda.time.format.DateTimeFormatter ym = org.joda.time.format.ISODateTimeFormat.Constants.yearMonth();

		private static final org.joda.time.format.DateTimeFormatter ymd = org.joda.time.format.ISODateTimeFormat.Constants.yearMonthDay();

		private static final org.joda.time.format.DateTimeFormatter ww = org.joda.time.format.ISODateTimeFormat.Constants.weekyearWeek();

		private static final org.joda.time.format.DateTimeFormatter wwd = org.joda.time.format.ISODateTimeFormat.Constants.weekyearWeekDay();

		private static final org.joda.time.format.DateTimeFormatter hm = org.joda.time.format.ISODateTimeFormat.Constants.hourMinute();

		private static final org.joda.time.format.DateTimeFormatter hms = org.joda.time.format.ISODateTimeFormat.Constants.hourMinuteSecond();

		private static final org.joda.time.format.DateTimeFormatter hmsl = org.joda.time.format.ISODateTimeFormat.Constants.hourMinuteSecondMillis();

		private static final org.joda.time.format.DateTimeFormatter hmsf = org.joda.time.format.ISODateTimeFormat.Constants.hourMinuteSecondFraction();

		private static final org.joda.time.format.DateTimeFormatter dh = org.joda.time.format.ISODateTimeFormat.Constants.dateHour();

		private static final org.joda.time.format.DateTimeFormatter dhm = org.joda.time.format.ISODateTimeFormat.Constants.dateHourMinute();

		private static final org.joda.time.format.DateTimeFormatter dhms = org.joda.time.format.ISODateTimeFormat.Constants.dateHourMinuteSecond();

		private static final org.joda.time.format.DateTimeFormatter dhmsl = org.joda.time.format.ISODateTimeFormat.Constants.dateHourMinuteSecondMillis();

		private static final org.joda.time.format.DateTimeFormatter dhmsf = org.joda.time.format.ISODateTimeFormat.Constants.dateHourMinuteSecondFraction();

		private static final org.joda.time.format.DateTimeFormatter t = org.joda.time.format.ISODateTimeFormat.Constants.time();

		private static final org.joda.time.format.DateTimeFormatter tx = org.joda.time.format.ISODateTimeFormat.Constants.timeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter tt = org.joda.time.format.ISODateTimeFormat.Constants.tTime();

		private static final org.joda.time.format.DateTimeFormatter ttx = org.joda.time.format.ISODateTimeFormat.Constants.tTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter dt = org.joda.time.format.ISODateTimeFormat.Constants.dateTime();

		private static final org.joda.time.format.DateTimeFormatter dtx = org.joda.time.format.ISODateTimeFormat.Constants.dateTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter wdt = org.joda.time.format.ISODateTimeFormat.Constants.weekDateTime();

		private static final org.joda.time.format.DateTimeFormatter wdtx = org.joda.time.format.ISODateTimeFormat.Constants.weekDateTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter od = org.joda.time.format.ISODateTimeFormat.Constants.ordinalDate();

		private static final org.joda.time.format.DateTimeFormatter odt = org.joda.time.format.ISODateTimeFormat.Constants.ordinalDateTime();

		private static final org.joda.time.format.DateTimeFormatter odtx = org.joda.time.format.ISODateTimeFormat.Constants.ordinalDateTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter bd = org.joda.time.format.ISODateTimeFormat.Constants.basicDate();

		private static final org.joda.time.format.DateTimeFormatter bt = org.joda.time.format.ISODateTimeFormat.Constants.basicTime();

		private static final org.joda.time.format.DateTimeFormatter btx = org.joda.time.format.ISODateTimeFormat.Constants.basicTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter btt = org.joda.time.format.ISODateTimeFormat.Constants.basicTTime();

		private static final org.joda.time.format.DateTimeFormatter bttx = org.joda.time.format.ISODateTimeFormat.Constants.basicTTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter bdt = org.joda.time.format.ISODateTimeFormat.Constants.basicDateTime();

		private static final org.joda.time.format.DateTimeFormatter bdtx = org.joda.time.format.ISODateTimeFormat.Constants.basicDateTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter bod = org.joda.time.format.ISODateTimeFormat.Constants.basicOrdinalDate();

		private static final org.joda.time.format.DateTimeFormatter bodt = org.joda.time.format.ISODateTimeFormat.Constants.basicOrdinalDateTime();

		private static final org.joda.time.format.DateTimeFormatter bodtx = org.joda.time.format.ISODateTimeFormat.Constants.basicOrdinalDateTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter bwd = org.joda.time.format.ISODateTimeFormat.Constants.basicWeekDate();

		private static final org.joda.time.format.DateTimeFormatter bwdt = org.joda.time.format.ISODateTimeFormat.Constants.basicWeekDateTime();

		private static final org.joda.time.format.DateTimeFormatter bwdtx = org.joda.time.format.ISODateTimeFormat.Constants.basicWeekDateTimeNoMillis();

		private static final org.joda.time.format.DateTimeFormatter dpe = org.joda.time.format.ISODateTimeFormat.Constants.dateElementParser();

		private static final org.joda.time.format.DateTimeFormatter tpe = org.joda.time.format.ISODateTimeFormat.Constants.timeElementParser();

		private static final org.joda.time.format.DateTimeFormatter dp = org.joda.time.format.ISODateTimeFormat.Constants.dateParser();

		private static final org.joda.time.format.DateTimeFormatter ldp = org.joda.time.format.ISODateTimeFormat.Constants.localDateParser();

		private static final org.joda.time.format.DateTimeFormatter tp = org.joda.time.format.ISODateTimeFormat.Constants.timeParser();

		private static final org.joda.time.format.DateTimeFormatter ltp = org.joda.time.format.ISODateTimeFormat.Constants.localTimeParser();

		private static final org.joda.time.format.DateTimeFormatter dtp = org.joda.time.format.ISODateTimeFormat.Constants.dateTimeParser();

		private static final org.joda.time.format.DateTimeFormatter dotp = org.joda.time.format.ISODateTimeFormat.Constants.dateOptionalTimeParser();

		private static final org.joda.time.format.DateTimeFormatter ldotp = org.joda.time.format.ISODateTimeFormat.Constants.localDateOptionalTimeParser();

		private static org.joda.time.format.DateTimeFormatter dateParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dp) == null) {
				org.joda.time.format.DateTimeParser tOffset = new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('T').append(org.joda.time.format.ISODateTimeFormat.Constants.offsetElement()).toParser();
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.dateElementParser()).appendOptional(tOffset).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dp;
		}

		private static org.joda.time.format.DateTimeFormatter localDateParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ldp) == null) {
				return org.joda.time.format.ISODateTimeFormat.Constants.dateElementParser().withZoneUTC();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ldp;
		}

		private static org.joda.time.format.DateTimeFormatter dateElementParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dpe) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(null, new org.joda.time.format.DateTimeParser[]{ new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.yearElement()).appendOptional(new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.monthElement()).appendOptional(org.joda.time.format.ISODateTimeFormat.Constants.dayOfMonthElement().getParser()).toParser()).toParser() , new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.weekyearElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.weekElement()).appendOptional(org.joda.time.format.ISODateTimeFormat.Constants.dayOfWeekElement().getParser()).toParser() , new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.yearElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.dayOfYearElement()).toParser() }).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dpe;
		}

		private static org.joda.time.format.DateTimeFormatter timeParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.tp) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendOptional(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement().getParser()).append(org.joda.time.format.ISODateTimeFormat.Constants.timeElementParser()).appendOptional(org.joda.time.format.ISODateTimeFormat.Constants.offsetElement().getParser()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.tp;
		}

		private static org.joda.time.format.DateTimeFormatter localTimeParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ltp) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendOptional(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement().getParser()).append(org.joda.time.format.ISODateTimeFormat.Constants.timeElementParser()).toFormatter().withZoneUTC();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ltp;
		}

		private static org.joda.time.format.DateTimeFormatter timeElementParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.tpe) == null) {
				org.joda.time.format.DateTimeParser decimalPoint = new org.joda.time.format.DateTimeFormatterBuilder().append(null, new org.joda.time.format.DateTimeParser[]{ new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('.').toParser() , new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral(',').toParser() }).toParser();
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.hourElement()).append(null, new org.joda.time.format.DateTimeParser[]{ new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.minuteElement()).append(null, new org.joda.time.format.DateTimeParser[]{ new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.secondElement()).appendOptional(new org.joda.time.format.DateTimeFormatterBuilder().append(decimalPoint).appendFractionOfSecond(1, 9).toParser()).toParser() , new org.joda.time.format.DateTimeFormatterBuilder().append(decimalPoint).appendFractionOfMinute(1, 9).toParser() , null }).toParser() , new org.joda.time.format.DateTimeFormatterBuilder().append(decimalPoint).appendFractionOfHour(1, 9).toParser() , null }).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.tpe;
		}

		private static org.joda.time.format.DateTimeFormatter dateTimeParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dtp) == null) {
				org.joda.time.format.DateTimeParser time = new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('T').append(org.joda.time.format.ISODateTimeFormat.Constants.timeElementParser()).appendOptional(org.joda.time.format.ISODateTimeFormat.Constants.offsetElement().getParser()).toParser();
				return new org.joda.time.format.DateTimeFormatterBuilder().append(null, new org.joda.time.format.DateTimeParser[]{ time , org.joda.time.format.ISODateTimeFormat.Constants.dateOptionalTimeParser().getParser() }).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dtp;
		}

		private static org.joda.time.format.DateTimeFormatter dateOptionalTimeParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dotp) == null) {
				org.joda.time.format.DateTimeParser timeOrOffset = new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('T').appendOptional(org.joda.time.format.ISODateTimeFormat.Constants.timeElementParser().getParser()).appendOptional(org.joda.time.format.ISODateTimeFormat.Constants.offsetElement().getParser()).toParser();
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.dateElementParser()).appendOptional(timeOrOffset).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dotp;
		}

		private static org.joda.time.format.DateTimeFormatter localDateOptionalTimeParser() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ldotp) == null) {
				org.joda.time.format.DateTimeParser time = new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('T').append(org.joda.time.format.ISODateTimeFormat.Constants.timeElementParser()).toParser();
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.dateElementParser()).appendOptional(time).toFormatter().withZoneUTC();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ldotp;
		}

		private static org.joda.time.format.DateTimeFormatter time() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.t) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.hourMinuteSecondFraction()).append(org.joda.time.format.ISODateTimeFormat.Constants.offsetElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.t;
		}

		private static org.joda.time.format.DateTimeFormatter timeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.tx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.hourMinuteSecond()).append(org.joda.time.format.ISODateTimeFormat.Constants.offsetElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.tx;
		}

		private static org.joda.time.format.DateTimeFormatter tTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.tt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.time()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.tt;
		}

		private static org.joda.time.format.DateTimeFormatter tTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ttx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.timeNoMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ttx;
		}

		private static org.joda.time.format.DateTimeFormatter dateTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.date()).append(org.joda.time.format.ISODateTimeFormat.Constants.tTime()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dt;
		}

		private static org.joda.time.format.DateTimeFormatter dateTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dtx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.date()).append(org.joda.time.format.ISODateTimeFormat.Constants.tTimeNoMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dtx;
		}

		private static org.joda.time.format.DateTimeFormatter ordinalDate() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.od) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.yearElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.dayOfYearElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.od;
		}

		private static org.joda.time.format.DateTimeFormatter ordinalDateTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.odt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.ordinalDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.tTime()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.odt;
		}

		private static org.joda.time.format.DateTimeFormatter ordinalDateTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.odtx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.ordinalDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.tTimeNoMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.odtx;
		}

		private static org.joda.time.format.DateTimeFormatter weekDateTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.wdt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.weekDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.tTime()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.wdt;
		}

		private static org.joda.time.format.DateTimeFormatter weekDateTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.wdtx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.weekDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.tTimeNoMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.wdtx;
		}

		private static org.joda.time.format.DateTimeFormatter basicDate() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bd) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendYear(4, 4).appendFixedDecimal(org.joda.time.DateTimeFieldType.monthOfYear(), 2).appendFixedDecimal(org.joda.time.DateTimeFieldType.dayOfMonth(), 2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bd;
		}

		private static org.joda.time.format.DateTimeFormatter basicTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendFixedDecimal(org.joda.time.DateTimeFieldType.hourOfDay(), 2).appendFixedDecimal(org.joda.time.DateTimeFieldType.minuteOfHour(), 2).appendFixedDecimal(org.joda.time.DateTimeFieldType.secondOfMinute(), 2).appendLiteral('.').appendFractionOfSecond(3, 9).appendTimeZoneOffset("Z", false, 2, 2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bt;
		}

		private static org.joda.time.format.DateTimeFormatter basicTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.btx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendFixedDecimal(org.joda.time.DateTimeFieldType.hourOfDay(), 2).appendFixedDecimal(org.joda.time.DateTimeFieldType.minuteOfHour(), 2).appendFixedDecimal(org.joda.time.DateTimeFieldType.secondOfMinute(), 2).appendTimeZoneOffset("Z", false, 2, 2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.btx;
		}

		private static org.joda.time.format.DateTimeFormatter basicTTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.btt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.basicTime()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.btt;
		}

		private static org.joda.time.format.DateTimeFormatter basicTTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bttx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.basicTimeNoMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bttx;
		}

		private static org.joda.time.format.DateTimeFormatter basicDateTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bdt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.basicDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.basicTTime()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bdt;
		}

		private static org.joda.time.format.DateTimeFormatter basicDateTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bdtx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.basicDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.basicTTimeNoMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bdtx;
		}

		private static org.joda.time.format.DateTimeFormatter basicOrdinalDate() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bod) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendYear(4, 4).appendFixedDecimal(org.joda.time.DateTimeFieldType.dayOfYear(), 3).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bod;
		}

		private static org.joda.time.format.DateTimeFormatter basicOrdinalDateTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bodt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.basicOrdinalDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.basicTTime()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bodt;
		}

		private static org.joda.time.format.DateTimeFormatter basicOrdinalDateTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bodtx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.basicOrdinalDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.basicTTimeNoMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bodtx;
		}

		private static org.joda.time.format.DateTimeFormatter basicWeekDate() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bwd) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendWeekyear(4, 4).appendLiteral('W').appendFixedDecimal(org.joda.time.DateTimeFieldType.weekOfWeekyear(), 2).appendFixedDecimal(org.joda.time.DateTimeFieldType.dayOfWeek(), 1).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bwd;
		}

		private static org.joda.time.format.DateTimeFormatter basicWeekDateTime() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bwdt) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.basicWeekDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.basicTTime()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bwdt;
		}

		private static org.joda.time.format.DateTimeFormatter basicWeekDateTimeNoMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.bwdtx) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.basicWeekDate()).append(org.joda.time.format.ISODateTimeFormat.Constants.basicTTimeNoMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.bwdtx;
		}

		private static org.joda.time.format.DateTimeFormatter yearMonth() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ym) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.yearElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.monthElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ym;
		}

		private static org.joda.time.format.DateTimeFormatter yearMonthDay() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ymd) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.yearElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.monthElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.dayOfMonthElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ymd;
		}

		private static org.joda.time.format.DateTimeFormatter weekyearWeek() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ww) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.weekyearElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.weekElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ww;
		}

		private static org.joda.time.format.DateTimeFormatter weekyearWeekDay() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.wwd) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.weekyearElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.weekElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.dayOfWeekElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.wwd;
		}

		private static org.joda.time.format.DateTimeFormatter hourMinute() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.hm) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.hourElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.minuteElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.hm;
		}

		private static org.joda.time.format.DateTimeFormatter hourMinuteSecond() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.hms) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.hourElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.minuteElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.secondElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.hms;
		}

		private static org.joda.time.format.DateTimeFormatter hourMinuteSecondMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.hmsl) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.hourElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.minuteElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.secondElement()).appendLiteral('.').appendFractionOfSecond(3, 3).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.hmsl;
		}

		private static org.joda.time.format.DateTimeFormatter hourMinuteSecondFraction() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.hmsf) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.Constants.hourElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.minuteElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.secondElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.fractionElement()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.hmsf;
		}

		private static org.joda.time.format.DateTimeFormatter dateHour() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dh) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.date()).append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.hour()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dh;
		}

		private static org.joda.time.format.DateTimeFormatter dateHourMinute() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dhm) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.date()).append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.hourMinute()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dhm;
		}

		private static org.joda.time.format.DateTimeFormatter dateHourMinuteSecond() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dhms) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.date()).append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.hourMinuteSecond()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dhms;
		}

		private static org.joda.time.format.DateTimeFormatter dateHourMinuteSecondMillis() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dhmsl) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.date()).append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.hourMinuteSecondMillis()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dhmsl;
		}

		private static org.joda.time.format.DateTimeFormatter dateHourMinuteSecondFraction() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dhmsf) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().append(org.joda.time.format.ISODateTimeFormat.date()).append(org.joda.time.format.ISODateTimeFormat.Constants.literalTElement()).append(org.joda.time.format.ISODateTimeFormat.Constants.hourMinuteSecondFraction()).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dhmsf;
		}

		private static org.joda.time.format.DateTimeFormatter yearElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ye) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendYear(4, 9).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ye;
		}

		private static org.joda.time.format.DateTimeFormatter monthElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.mye) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('-').appendMonthOfYear(2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.mye;
		}

		private static org.joda.time.format.DateTimeFormatter dayOfMonthElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dme) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('-').appendDayOfMonth(2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dme;
		}

		private static org.joda.time.format.DateTimeFormatter weekyearElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.we) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendWeekyear(4, 9).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.we;
		}

		private static org.joda.time.format.DateTimeFormatter weekElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.wwe) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral("-W").appendWeekOfWeekyear(2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.wwe;
		}

		private static org.joda.time.format.DateTimeFormatter dayOfWeekElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dwe) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('-').appendDayOfWeek(1).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dwe;
		}

		private static org.joda.time.format.DateTimeFormatter dayOfYearElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.dye) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('-').appendDayOfYear(3).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.dye;
		}

		private static org.joda.time.format.DateTimeFormatter literalTElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.lte) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('T').toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.lte;
		}

		private static org.joda.time.format.DateTimeFormatter hourElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.hde) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendHourOfDay(2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.hde;
		}

		private static org.joda.time.format.DateTimeFormatter minuteElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.mhe) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral(':').appendMinuteOfHour(2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.mhe;
		}

		private static org.joda.time.format.DateTimeFormatter secondElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.sme) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral(':').appendSecondOfMinute(2).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.sme;
		}

		private static org.joda.time.format.DateTimeFormatter fractionElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.fse) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendLiteral('.').appendFractionOfSecond(3, 9).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.fse;
		}

		private static org.joda.time.format.DateTimeFormatter offsetElement() {
			if ((org.joda.time.format.ISODateTimeFormat.Constants.ze) == null) {
				return new org.joda.time.format.DateTimeFormatterBuilder().appendTimeZoneOffset("Z", true, 2, 4).toFormatter();
			} 
			return org.joda.time.format.ISODateTimeFormat.Constants.ze;
		}
	}
}

