package org.apache.commons.math3.analysis;


public interface DifferentiableUnivariateFunction extends org.apache.commons.math3.analysis.UnivariateFunction {
	org.apache.commons.math3.analysis.UnivariateFunction derivative();
}

