package org.apache.commons.math3.stat.ranking;


public enum NaNStrategy {
MINIMAL, MAXIMAL, REMOVED, FIXED;}

