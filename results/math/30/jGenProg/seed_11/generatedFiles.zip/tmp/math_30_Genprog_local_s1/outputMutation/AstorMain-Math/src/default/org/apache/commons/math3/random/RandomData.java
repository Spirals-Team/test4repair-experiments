package org.apache.commons.math3.random;


public interface RandomData {
	java.lang.String nextHexString(int len);

	int nextInt(int lower, int upper);

	long nextLong(long lower, long upper);

	java.lang.String nextSecureHexString(int len);

	int nextSecureInt(int lower, int upper);

	long nextSecureLong(long lower, long upper);

	long nextPoisson(double mean);

	double nextGaussian(double mu, double sigma);

	double nextExponential(double mean);

	double nextUniform(double lower, double upper);

	double nextUniform(double lower, double upper, boolean lowerInclusive);

	int[] nextPermutation(int n, int k);

	java.lang.Object[] nextSample(java.util.Collection<?> c, int k);
}

