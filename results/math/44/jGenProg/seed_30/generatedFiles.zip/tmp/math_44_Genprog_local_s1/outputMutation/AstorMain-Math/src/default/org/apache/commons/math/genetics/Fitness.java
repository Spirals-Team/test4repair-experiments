package org.apache.commons.math.genetics;


public interface Fitness {
	double fitness();
}

