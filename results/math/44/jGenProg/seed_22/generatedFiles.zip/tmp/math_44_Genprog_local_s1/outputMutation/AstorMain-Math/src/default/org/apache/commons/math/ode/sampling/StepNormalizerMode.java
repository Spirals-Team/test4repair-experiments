package org.apache.commons.math.ode.sampling;


public enum StepNormalizerMode {
INCREMENT, MULTIPLES;}

