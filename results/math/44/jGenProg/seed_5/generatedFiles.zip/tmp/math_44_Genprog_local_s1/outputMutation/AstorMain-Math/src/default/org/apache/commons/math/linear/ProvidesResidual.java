package org.apache.commons.math.linear;


public interface ProvidesResidual {
	org.apache.commons.math.linear.RealVector getResidual();
}

