package org.apache.commons.math.exception.util;


public interface ExceptionContextProvider {
	org.apache.commons.math.exception.util.ExceptionContext getContext();
}

