package org.apache.commons.math.analysis.function;


public class Identity implements org.apache.commons.math.analysis.UnivariateRealFunction {
	public double value(double x) {
		return x;
	}
}

