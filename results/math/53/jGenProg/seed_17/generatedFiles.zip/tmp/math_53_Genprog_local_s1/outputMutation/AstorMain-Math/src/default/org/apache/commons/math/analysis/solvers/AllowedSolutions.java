package org.apache.commons.math.analysis.solvers;


public enum AllowedSolutions {
ANY_SIDE, LEFT_SIDE, RIGHT_SIDE, BELOW_SIDE, ABOVE_SIDE;}

