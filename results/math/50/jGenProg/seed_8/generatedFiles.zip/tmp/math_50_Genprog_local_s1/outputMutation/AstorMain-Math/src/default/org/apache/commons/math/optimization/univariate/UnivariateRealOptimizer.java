package org.apache.commons.math.optimization.univariate;


public interface UnivariateRealOptimizer extends org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer<org.apache.commons.math.analysis.UnivariateRealFunction> {}

