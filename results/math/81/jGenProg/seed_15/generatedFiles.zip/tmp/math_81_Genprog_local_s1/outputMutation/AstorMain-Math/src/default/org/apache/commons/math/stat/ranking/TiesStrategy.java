package org.apache.commons.math.stat.ranking;


public enum TiesStrategy {
SEQUENTIAL, MINIMUM, MAXIMUM, AVERAGE, RANDOM;}

