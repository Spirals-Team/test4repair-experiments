package org.apache.commons.math.analysis.function;


public class Minus implements org.apache.commons.math.analysis.UnivariateRealFunction {
	public double value(double x) {
		return -x;
	}
}

