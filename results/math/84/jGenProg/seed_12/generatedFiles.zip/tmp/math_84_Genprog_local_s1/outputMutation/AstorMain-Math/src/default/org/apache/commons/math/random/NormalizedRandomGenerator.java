package org.apache.commons.math.random;


public interface NormalizedRandomGenerator {
	public double nextNormalizedDouble();
}

