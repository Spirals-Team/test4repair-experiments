package org.apache.commons.math3.optimization;


public class Weight implements org.apache.commons.math3.optimization.OptimizationData {
	private final org.apache.commons.math3.linear.RealMatrix weightMatrix;

	public Weight(double[] weight) {
		final int dim = weight.length;
		weightMatrix = new org.apache.commons.math3.linear.Array2DRowRealMatrix(dim , dim);
		for (int i = 0 ; i < dim ; i++) {
			weightMatrix.setEntry(i, i, weight[i]);
		}
	}

	public Weight(org.apache.commons.math3.linear.RealMatrix weight) {
		if ((weight.getColumnDimension()) != (weight.getRowDimension())) {
			throw new org.apache.commons.math3.linear.NonSquareMatrixException(weight.getColumnDimension() , weight.getRowDimension());
		} 
		weightMatrix = weight.copy();
	}

	public org.apache.commons.math3.linear.RealMatrix getWeight() {
		return weightMatrix.copy();
	}
}

