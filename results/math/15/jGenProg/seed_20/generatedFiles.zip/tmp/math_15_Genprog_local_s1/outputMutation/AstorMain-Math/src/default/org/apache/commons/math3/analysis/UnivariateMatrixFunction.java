package org.apache.commons.math3.analysis;


public interface UnivariateMatrixFunction {
	double[][] value(double x);
}

