package org.apache.commons.math3.optimization;


public interface MultivariateDifferentiableVectorOptimizer extends org.apache.commons.math3.optimization.BaseMultivariateVectorOptimizer<org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction> {}

