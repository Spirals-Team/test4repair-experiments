package org.apache.commons.math3.optimization;


public interface OptimizationData {}

