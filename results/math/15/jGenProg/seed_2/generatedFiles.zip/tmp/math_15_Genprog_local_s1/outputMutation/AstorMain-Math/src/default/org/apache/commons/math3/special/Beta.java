package org.apache.commons.math3.special;


public class Beta {
	private static final double DEFAULT_EPSILON = 1.0E-14;

	private static final double[] DELTA = new double[]{ 0.08333333333333333 , -2.777777777777778E-5 , 7.936507936507937E-8 , -5.952380952380953E-10 , 8.417508417508329E-12 , -1.917526917518546E-13 , 6.410256405103255E-15 , -2.955065141253382E-16 , 1.7964371635940225E-17 , -1.3922896466162779E-18 , 1.338028550140209E-19 , -1.542460098679661E-20 , 1.9770199298095743E-21 , -2.3406566479399704E-22 , 1.713480149663986E-23 };

	private Beta() {
	}

	public static double regularizedBeta(double x, double a, double b) {
		return org.apache.commons.math3.special.Beta.regularizedBeta(x, a, b, org.apache.commons.math3.special.Beta.DEFAULT_EPSILON, java.lang.Integer.MAX_VALUE);
	}

	public static double regularizedBeta(double x, double a, double b, double epsilon) {
		return org.apache.commons.math3.special.Beta.regularizedBeta(x, a, b, epsilon, java.lang.Integer.MAX_VALUE);
	}

	public static double regularizedBeta(double x, double a, double b, int maxIterations) {
		return org.apache.commons.math3.special.Beta.regularizedBeta(x, a, b, org.apache.commons.math3.special.Beta.DEFAULT_EPSILON, maxIterations);
	}

	public static double regularizedBeta(double x, final double a, final double b, double epsilon, int maxIterations) {
		double ret;
		if (((((((java.lang.Double.isNaN(x)) || (java.lang.Double.isNaN(a))) || (java.lang.Double.isNaN(b))) || (x < 0)) || (x > 1)) || (a <= 0.0)) || (b <= 0.0)) {
			ret = java.lang.Double.NaN;
		} else if (x > ((a + 1.0) / ((a + b) + 2.0))) {
			ret = 1.0 - (org.apache.commons.math3.special.Beta.regularizedBeta((1.0 - x), b, a, epsilon, maxIterations));
		} else {
			org.apache.commons.math3.util.ContinuedFraction fraction = new org.apache.commons.math3.util.ContinuedFraction() {
				@java.lang.Override
				protected double getB(int n, double x) {
					double ret;
					double m;
					if ((n % 2) == 0) {
						m = n / 2.0;
						ret = ((m * (b - m)) * x) / (((a + (2 * m)) - 1) * (a + (2 * m)));
					} else {
						m = (n - 1.0) / 2.0;
						ret = (-(((a + m) * ((a + b) + m)) * x)) / ((a + (2 * m)) * ((a + (2 * m)) + 1.0));
					}
					return ret;
				}

				@java.lang.Override
				protected double getA(int n, double x) {
					return 1.0;
				}
			};
			ret = ((org.apache.commons.math3.util.FastMath.exp(((((a * (org.apache.commons.math3.util.FastMath.log(x))) + (b * (org.apache.commons.math3.util.FastMath.log((1.0 - x))))) - (org.apache.commons.math3.util.FastMath.log(a))) - (org.apache.commons.math3.special.Beta.logBeta(a, b, epsilon, maxIterations))))) * 1.0) / (fraction.evaluate(x, epsilon, maxIterations));
		}
		return ret;
	}

	public static double logBeta(double a, double b) {
		return org.apache.commons.math3.special.Beta.logBeta(a, b, org.apache.commons.math3.special.Beta.DEFAULT_EPSILON, java.lang.Integer.MAX_VALUE);
	}

	public static double logBeta(double a, double b, double epsilon, int maxIterations) {
		double ret;
		if ((((java.lang.Double.isNaN(a)) || (java.lang.Double.isNaN(b))) || (a <= 0.0)) || (b <= 0.0)) {
			ret = java.lang.Double.NaN;
		} else {
			ret = ((org.apache.commons.math3.special.Gamma.logGamma(a)) + (org.apache.commons.math3.special.Gamma.logGamma(b))) - (org.apache.commons.math3.special.Gamma.logGamma((a + b)));
		}
		return ret;
	}

	static final double bcorr(final double p, final double q) {
		if (p < 10.0) {
			throw new org.apache.commons.math3.exception.NumberIsTooSmallException(p , 10.0 , true);
		} 
		if (q < 10.0) {
			throw new org.apache.commons.math3.exception.NumberIsTooSmallException(q , 10.0 , true);
		} 
		final double a = org.apache.commons.math3.util.FastMath.min(p, q);
		final double b = org.apache.commons.math3.util.FastMath.max(p, q);
		final double h = a / b;
		final double c = h / (1.0 + h);
		final double x = 1.0 / (1.0 + h);
		final double x2 = x * x;
		final double[] s = new double[org.apache.commons.math3.special.Beta.DELTA.length];
		s[0] = 1.0;
		for (int i = 1 ; i < (s.length) ; i++) {
			s[i] = 1.0 + (x + (x2 * (s[(i - 1)])));
		}
		double tmp = 10.0 / b;
		final double tb = tmp * tmp;
		double w = (org.apache.commons.math3.special.Beta.DELTA[((org.apache.commons.math3.special.Beta.DELTA.length) - 1)]) * (s[((s.length) - 1)]);
		for (int i = (org.apache.commons.math3.special.Beta.DELTA.length) - 2 ; i >= 0 ; i--) {
			w = (tb * w) + ((org.apache.commons.math3.special.Beta.DELTA[i]) * (s[i]));
		}
		w *= c / b;
		tmp = 10.0 / a;
		final double ta = tmp * tmp;
		double z = org.apache.commons.math3.special.Beta.DELTA[((org.apache.commons.math3.special.Beta.DELTA.length) - 1)];
		for (int i = (org.apache.commons.math3.special.Beta.DELTA.length) - 2 ; i >= 0 ; i--) {
			z = (ta * z) + (org.apache.commons.math3.special.Beta.DELTA[i]);
		}
		return (z / a) + w;
	}
}

