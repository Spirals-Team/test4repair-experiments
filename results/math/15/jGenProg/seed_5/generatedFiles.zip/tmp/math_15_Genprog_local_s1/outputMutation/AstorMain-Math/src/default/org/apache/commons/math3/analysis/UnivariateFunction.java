package org.apache.commons.math3.analysis;


public interface UnivariateFunction {
	double value(double x);
}

