package org.apache.commons.math3.optimization;


public interface MultivariateDifferentiableOptimizer extends org.apache.commons.math3.optimization.BaseMultivariateOptimizer<org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableFunction> {}

