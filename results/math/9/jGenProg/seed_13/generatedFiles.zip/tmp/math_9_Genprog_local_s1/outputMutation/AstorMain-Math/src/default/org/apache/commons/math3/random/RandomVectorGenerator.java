package org.apache.commons.math3.random;


public interface RandomVectorGenerator {
	double[] nextVector();
}

