package org.apache.commons.math3.genetics;


public interface StoppingCondition {
	boolean isSatisfied(org.apache.commons.math3.genetics.Population population);
}

