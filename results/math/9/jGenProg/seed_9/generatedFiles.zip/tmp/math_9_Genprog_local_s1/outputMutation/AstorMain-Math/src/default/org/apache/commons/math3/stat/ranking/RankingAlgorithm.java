package org.apache.commons.math3.stat.ranking;


public interface RankingAlgorithm {
	double[] rank(double[] data);
}

