package org.apache.commons.math3.optimization.general;


@java.lang.Deprecated
public enum ConjugateGradientFormula {
FLETCHER_REEVES, POLAK_RIBIERE;}

