package org.apache.commons.math3.analysis;


@java.lang.Deprecated
public interface DifferentiableUnivariateFunction extends org.apache.commons.math3.analysis.UnivariateFunction {
	org.apache.commons.math3.analysis.UnivariateFunction derivative();
}

