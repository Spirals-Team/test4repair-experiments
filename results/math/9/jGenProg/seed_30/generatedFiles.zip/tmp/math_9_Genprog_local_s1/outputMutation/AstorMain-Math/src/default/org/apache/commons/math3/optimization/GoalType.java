package org.apache.commons.math3.optimization;


@java.lang.Deprecated
public enum GoalType implements java.io.Serializable {
MAXIMIZE, MINIMIZE;}

