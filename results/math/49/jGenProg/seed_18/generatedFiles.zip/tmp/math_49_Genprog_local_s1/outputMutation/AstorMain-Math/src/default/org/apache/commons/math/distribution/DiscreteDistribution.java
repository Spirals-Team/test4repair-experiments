package org.apache.commons.math.distribution;


public interface DiscreteDistribution extends org.apache.commons.math.distribution.Distribution {
	double probability(double x);
}

