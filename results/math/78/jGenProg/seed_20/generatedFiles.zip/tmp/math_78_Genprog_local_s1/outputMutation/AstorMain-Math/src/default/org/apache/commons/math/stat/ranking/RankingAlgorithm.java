package org.apache.commons.math.stat.ranking;


public interface RankingAlgorithm {
	double[] rank(double[] data);
}

