package org.apache.commons.math3.optimization.general;


public abstract class AbstractDifferentiableOptimizer extends org.apache.commons.math3.optimization.direct.BaseAbstractMultivariateOptimizer<org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableFunction> implements org.apache.commons.math3.optimization.MultivariateDifferentiableOptimizer {
	private org.apache.commons.math3.analysis.MultivariateVectorFunction gradient;

	protected AbstractDifferentiableOptimizer(org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> checker) {
		super(checker);
	}

	protected double[] computeObjectiveGradient(final double[] evaluationPoint) {
		return gradient.value(evaluationPoint);
	}

	@java.lang.Override
	public org.apache.commons.math3.optimization.PointValuePair optimize(final int maxEval, final org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableFunction f, final org.apache.commons.math3.optimization.GoalType goalType, final double[] startPoint) {
		gradient = new org.apache.commons.math3.analysis.differentiation.GradientFunction(f);
		return super.optimize(maxEval, f, goalType, startPoint);
	}
}

