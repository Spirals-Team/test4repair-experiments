package org.apache.commons.math3.stat.descriptive.moment;


public class Mean extends org.apache.commons.math3.stat.descriptive.AbstractStorelessUnivariateStatistic implements java.io.Serializable , org.apache.commons.math3.stat.descriptive.WeightedEvaluation {
	private static final long serialVersionUID = -1296043746617791564L;

	protected org.apache.commons.math3.stat.descriptive.moment.FirstMoment moment;

	protected boolean incMoment;

	public Mean() {
		incMoment = true;
		moment = new org.apache.commons.math3.stat.descriptive.moment.FirstMoment();
	}

	public Mean(final org.apache.commons.math3.stat.descriptive.moment.FirstMoment m1) {
		org.apache.commons.math3.stat.descriptive.moment.Mean.this.moment = m1;
		incMoment = false;
	}

	public Mean(org.apache.commons.math3.stat.descriptive.moment.Mean original) throws org.apache.commons.math3.exception.NullArgumentException {
		org.apache.commons.math3.stat.descriptive.moment.Mean.copy(original, org.apache.commons.math3.stat.descriptive.moment.Mean.this);
	}

	@java.lang.Override
	public void increment(final double d) {
		if (incMoment) {
			moment.increment(d);
		} 
	}

	@java.lang.Override
	public void clear() {
		if (incMoment) {
			moment.clear();
		} 
	}

	@java.lang.Override
	public double getResult() {
		return moment.m1;
	}

	public long getN() {
		return moment.getN();
	}

	@java.lang.Override
	public double evaluate(final double[] values, final int begin, final int length) throws org.apache.commons.math3.exception.MathIllegalArgumentException {
		if (test(values, begin, length)) {
			org.apache.commons.math3.stat.descriptive.summary.Sum sum = new org.apache.commons.math3.stat.descriptive.summary.Sum();
			double sampleSize = length;
			double xbar = (sum.evaluate(values, begin, length)) / sampleSize;
			double correction = 0;
			for (int i = begin ; i < (begin + length) ; i++) {
				correction += (values[i]) - xbar;
			}
			return xbar + (correction / sampleSize);
		} 
		return java.lang.Double.NaN;
	}

	public double evaluate(final double[] values, final double[] weights, final int begin, final int length) throws org.apache.commons.math3.exception.MathIllegalArgumentException {
		if (test(values, weights, begin, length)) {
			org.apache.commons.math3.stat.descriptive.summary.Sum sum = new org.apache.commons.math3.stat.descriptive.summary.Sum();
			double sumw = sum.evaluate(weights, begin, length);
			double xbarw = (sum.evaluate(values, weights, begin, length)) / sumw;
			double correction = 0;
			for (int i = begin ; i < (begin + length) ; i++) {
				correction += (weights[i]) * ((values[i]) - xbarw);
			}
			return xbarw + (correction / sumw);
		} 
		return java.lang.Double.NaN;
	}

	public double evaluate(final double[] values, final double[] weights) throws org.apache.commons.math3.exception.MathIllegalArgumentException {
		return evaluate(values, weights, 0, values.length);
	}

	@java.lang.Override
	public org.apache.commons.math3.stat.descriptive.moment.Mean copy() {
		org.apache.commons.math3.stat.descriptive.moment.Mean result = new org.apache.commons.math3.stat.descriptive.moment.Mean();
		org.apache.commons.math3.stat.descriptive.moment.Mean.copy(org.apache.commons.math3.stat.descriptive.moment.Mean.this, result);
		return result;
	}

	public static void copy(org.apache.commons.math3.stat.descriptive.moment.Mean source, org.apache.commons.math3.stat.descriptive.moment.Mean dest) throws org.apache.commons.math3.exception.NullArgumentException {
		org.apache.commons.math3.util.MathUtils.checkNotNull(source);
		org.apache.commons.math3.util.MathUtils.checkNotNull(dest);
		dest.setData(source.getDataRef());
		dest.incMoment = source.incMoment;
		dest.moment = source.moment.copy();
	}
}

