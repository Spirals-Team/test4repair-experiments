package org.apache.commons.math3.genetics;


public interface PermutationChromosome<T> {
	java.util.List<T> decode(java.util.List<T> sequence);
}

