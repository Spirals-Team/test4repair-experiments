package org.apache.commons.math3.analysis.differentiation;


public interface UnivariateMatrixFunctionDifferentiator {
	org.apache.commons.math3.analysis.differentiation.UnivariateDifferentiableMatrixFunction differentiate(org.apache.commons.math3.analysis.UnivariateMatrixFunction function);
}

