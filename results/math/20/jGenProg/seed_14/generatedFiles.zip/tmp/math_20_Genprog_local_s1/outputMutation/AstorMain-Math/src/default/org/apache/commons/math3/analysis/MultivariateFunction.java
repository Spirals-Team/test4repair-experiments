package org.apache.commons.math3.analysis;


public interface MultivariateFunction {
	double value(double[] point);
}

