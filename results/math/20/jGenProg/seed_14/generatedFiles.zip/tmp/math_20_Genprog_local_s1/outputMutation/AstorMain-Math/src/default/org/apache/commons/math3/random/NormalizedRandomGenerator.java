package org.apache.commons.math3.random;


public interface NormalizedRandomGenerator {
	double nextNormalizedDouble();
}

