package org.apache.commons.math3.exception.util;


public interface ExceptionContextProvider {
	org.apache.commons.math3.exception.util.ExceptionContext getContext();
}

