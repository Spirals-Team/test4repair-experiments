package org.apache.commons.math3.analysis;


public interface DifferentiableMultivariateVectorFunction extends org.apache.commons.math3.analysis.MultivariateVectorFunction {
	org.apache.commons.math3.analysis.MultivariateMatrixFunction jacobian();
}

