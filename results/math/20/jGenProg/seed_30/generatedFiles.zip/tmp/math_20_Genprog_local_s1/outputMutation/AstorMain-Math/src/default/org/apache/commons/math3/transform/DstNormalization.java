package org.apache.commons.math3.transform;


public enum DstNormalization {
STANDARD_DST_I, ORTHOGONAL_DST_I;}

