package org.apache.commons.math3.optimization;


@java.lang.Deprecated
public interface DifferentiableMultivariateOptimizer extends org.apache.commons.math3.optimization.BaseMultivariateOptimizer<org.apache.commons.math3.analysis.DifferentiableMultivariateFunction> {}

