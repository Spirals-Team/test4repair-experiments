package org.apache.commons.math3.analysis;


@java.lang.Deprecated
public interface DifferentiableMultivariateVectorFunction extends org.apache.commons.math3.analysis.MultivariateVectorFunction {
	org.apache.commons.math3.analysis.MultivariateMatrixFunction jacobian();
}

