package org.apache.commons.math3.analysis;


public interface BivariateFunction {
	double value(double x, double y);
}

