package org.apache.commons.math3.linear;


@java.lang.Deprecated
public abstract class SparseRealVector extends org.apache.commons.math3.linear.RealVector {}

