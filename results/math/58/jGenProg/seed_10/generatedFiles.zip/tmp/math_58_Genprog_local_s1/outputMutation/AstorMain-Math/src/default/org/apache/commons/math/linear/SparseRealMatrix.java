package org.apache.commons.math.linear;


public interface SparseRealMatrix extends org.apache.commons.math.linear.RealMatrix {}

