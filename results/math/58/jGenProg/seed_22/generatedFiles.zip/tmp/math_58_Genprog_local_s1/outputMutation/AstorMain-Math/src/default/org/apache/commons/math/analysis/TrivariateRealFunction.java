package org.apache.commons.math.analysis;


public interface TrivariateRealFunction {
	double value(double x, double y, double z) throws org.apache.commons.math.exception.MathUserException;
}

