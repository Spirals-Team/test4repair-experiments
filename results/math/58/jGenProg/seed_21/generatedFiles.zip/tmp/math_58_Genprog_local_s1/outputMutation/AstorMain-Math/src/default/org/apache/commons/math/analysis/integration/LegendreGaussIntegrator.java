package org.apache.commons.math.analysis.integration;


public class LegendreGaussIntegrator extends org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl {
	private static final double[] ABSCISSAS_2 = new double[]{ (-1.0) / (org.apache.commons.math.util.FastMath.sqrt(3.0)) , 1.0 / (org.apache.commons.math.util.FastMath.sqrt(3.0)) };

	private static final double[] WEIGHTS_2 = new double[]{ 1.0 , 1.0 };

	private static final double[] ABSCISSAS_3 = new double[]{ -(org.apache.commons.math.util.FastMath.sqrt(0.6)) , 0.0 , org.apache.commons.math.util.FastMath.sqrt(0.6) };

	private static final double[] WEIGHTS_3 = new double[]{ 5.0 / 9.0 , 8.0 / 9.0 , 5.0 / 9.0 };

	private static final double[] ABSCISSAS_4 = new double[]{ -(org.apache.commons.math.util.FastMath.sqrt(((15.0 + (2.0 * (org.apache.commons.math.util.FastMath.sqrt(30.0)))) / 35.0))) , -(org.apache.commons.math.util.FastMath.sqrt(((15.0 - (2.0 * (org.apache.commons.math.util.FastMath.sqrt(30.0)))) / 35.0))) , org.apache.commons.math.util.FastMath.sqrt(((15.0 - (2.0 * (org.apache.commons.math.util.FastMath.sqrt(30.0)))) / 35.0)) , org.apache.commons.math.util.FastMath.sqrt(((15.0 + (2.0 * (org.apache.commons.math.util.FastMath.sqrt(30.0)))) / 35.0)) };

	private static final double[] WEIGHTS_4 = new double[]{ (90.0 - (5.0 * (org.apache.commons.math.util.FastMath.sqrt(30.0)))) / 180.0 , (90.0 + (5.0 * (org.apache.commons.math.util.FastMath.sqrt(30.0)))) / 180.0 , (90.0 + (5.0 * (org.apache.commons.math.util.FastMath.sqrt(30.0)))) / 180.0 , (90.0 - (5.0 * (org.apache.commons.math.util.FastMath.sqrt(30.0)))) / 180.0 };

	private static final double[] ABSCISSAS_5 = new double[]{ -(org.apache.commons.math.util.FastMath.sqrt(((35.0 + (2.0 * (org.apache.commons.math.util.FastMath.sqrt(70.0)))) / 63.0))) , -(org.apache.commons.math.util.FastMath.sqrt(((35.0 - (2.0 * (org.apache.commons.math.util.FastMath.sqrt(70.0)))) / 63.0))) , 0.0 , org.apache.commons.math.util.FastMath.sqrt(((35.0 - (2.0 * (org.apache.commons.math.util.FastMath.sqrt(70.0)))) / 63.0)) , org.apache.commons.math.util.FastMath.sqrt(((35.0 + (2.0 * (org.apache.commons.math.util.FastMath.sqrt(70.0)))) / 63.0)) };

	private static final double[] WEIGHTS_5 = new double[]{ (322.0 - (13.0 * (org.apache.commons.math.util.FastMath.sqrt(70.0)))) / 900.0 , (322.0 + (13.0 * (org.apache.commons.math.util.FastMath.sqrt(70.0)))) / 900.0 , 128.0 / 225.0 , (322.0 + (13.0 * (org.apache.commons.math.util.FastMath.sqrt(70.0)))) / 900.0 , (322.0 - (13.0 * (org.apache.commons.math.util.FastMath.sqrt(70.0)))) / 900.0 };

	private final double[] abscissas;

	private final double[] weights;

	public LegendreGaussIntegrator(final int n ,final int defaultMaximalIterationCount) throws java.lang.IllegalArgumentException {
		super(defaultMaximalIterationCount);
		switch (n) {
			case 2 :
				abscissas = org.apache.commons.math.analysis.integration.LegendreGaussIntegrator.ABSCISSAS_2;
				weights = org.apache.commons.math.analysis.integration.LegendreGaussIntegrator.WEIGHTS_2;
				break;
			case 3 :
				abscissas = org.apache.commons.math.analysis.integration.LegendreGaussIntegrator.ABSCISSAS_3;
				weights = org.apache.commons.math.analysis.integration.LegendreGaussIntegrator.WEIGHTS_3;
				break;
			case 4 :
				abscissas = org.apache.commons.math.analysis.integration.LegendreGaussIntegrator.ABSCISSAS_4;
				weights = org.apache.commons.math.analysis.integration.LegendreGaussIntegrator.WEIGHTS_4;
				break;
			case 5 :
				abscissas = org.apache.commons.math.analysis.integration.LegendreGaussIntegrator.ABSCISSAS_5;
				weights = org.apache.commons.math.analysis.integration.LegendreGaussIntegrator.WEIGHTS_5;
				break;
			default :
				throw org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED, n, 2, 5);
		}
	}

	@java.lang.Deprecated
	public double integrate(final double min, final double max) throws java.lang.IllegalArgumentException, org.apache.commons.math.ConvergenceException, org.apache.commons.math.exception.MathUserException {
		return integrate(f, min, max);
	}

	public double integrate(final org.apache.commons.math.analysis.UnivariateRealFunction f, final double min, final double max) throws java.lang.IllegalArgumentException, org.apache.commons.math.ConvergenceException, org.apache.commons.math.exception.MathUserException {
		clearResult();
		verifyInterval(min, max);
		verifyIterationCount();
		double oldt = stage(f, min, max, 1);
		int n = 2;
		for (int i = 0 ; i < (maximalIterationCount) ; ++i) {
			final double t = stage(f, min, max, n);
			final double delta = org.apache.commons.math.util.FastMath.abs((t - oldt));
			final double limit = org.apache.commons.math.util.FastMath.max(absoluteAccuracy, (((relativeAccuracy) * ((org.apache.commons.math.util.FastMath.abs(oldt)) + (org.apache.commons.math.util.FastMath.abs(t)))) * 0.5));
			if (((i + 1) >= (minimalIterationCount)) && (delta <= limit)) {
				setResult(t, i);
				return result;
			} 
			double ratio = org.apache.commons.math.util.FastMath.min(4, org.apache.commons.math.util.FastMath.pow((delta / limit), (0.5 / (abscissas.length))));
			n = org.apache.commons.math.util.FastMath.max(((int)(ratio * n)), (n + 1));
			oldt = t;
		}
		throw new org.apache.commons.math.exception.MaxCountExceededException(maximalIterationCount);
	}

	private double stage(final org.apache.commons.math.analysis.UnivariateRealFunction f, final double min, final double max, final int n) throws org.apache.commons.math.exception.MathUserException {
		final double step = (max - min) / n;
		final double halfStep = step / 2.0;
		double midPoint = min + halfStep;
		double sum = 0.0;
		for (int i = 0 ; i < n ; ++i) {
			for (int j = 0 ; j < (abscissas.length) ; ++j) {
				sum += (weights[j]) * (f.value((midPoint + (halfStep * (abscissas[j])))));
			}
			midPoint += step;
		}
		return halfStep * sum;
	}
}

