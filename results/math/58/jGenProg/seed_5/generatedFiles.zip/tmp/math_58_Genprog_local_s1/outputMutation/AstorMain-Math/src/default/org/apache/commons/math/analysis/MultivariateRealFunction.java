package org.apache.commons.math.analysis;


public interface MultivariateRealFunction {
	double value(double[] point);
}

