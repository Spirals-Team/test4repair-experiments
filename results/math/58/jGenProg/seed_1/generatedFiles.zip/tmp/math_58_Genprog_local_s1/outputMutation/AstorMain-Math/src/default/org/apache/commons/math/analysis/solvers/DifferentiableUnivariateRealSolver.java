package org.apache.commons.math.analysis.solvers;


public interface DifferentiableUnivariateRealSolver extends org.apache.commons.math.analysis.solvers.BaseUnivariateRealSolver<org.apache.commons.math.analysis.DifferentiableUnivariateRealFunction> {}

