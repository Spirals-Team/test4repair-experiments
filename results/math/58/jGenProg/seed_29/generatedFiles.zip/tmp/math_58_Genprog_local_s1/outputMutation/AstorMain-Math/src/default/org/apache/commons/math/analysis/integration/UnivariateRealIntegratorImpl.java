package org.apache.commons.math.analysis.integration;


public abstract class UnivariateRealIntegratorImpl extends org.apache.commons.math.analysis.integration.ConvergingAlgorithmImpl implements org.apache.commons.math.analysis.integration.UnivariateRealIntegrator {
	private static final long serialVersionUID = 6248808456637441533L;

	protected int minimalIterationCount;

	protected int defaultMinimalIterationCount;

	protected boolean resultComputed = false;

	protected double result;

	@java.lang.Deprecated
	protected org.apache.commons.math.analysis.UnivariateRealFunction f;

	@java.lang.Deprecated
	protected UnivariateRealIntegratorImpl(final org.apache.commons.math.analysis.UnivariateRealFunction f ,final int defaultMaximalIterationCount) throws java.lang.IllegalArgumentException {
		setMaximalIterationCount(defaultMaximalIterationCount);
		setAbsoluteAccuracy(1.0E-15);
		if (f == null) {
			throw new org.apache.commons.math.exception.NullArgumentException(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION);
		} 
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.f = f;
		setRelativeAccuracy(1.0E-6);
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.defaultMinimalIterationCount = 3;
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.minimalIterationCount = defaultMinimalIterationCount;
		verifyIterationCount();
	}

	protected UnivariateRealIntegratorImpl(final int defaultMaximalIterationCount) throws java.lang.IllegalArgumentException {
		setMaximalIterationCount(defaultMaximalIterationCount);
		setAbsoluteAccuracy(1.0E-15);
		setRelativeAccuracy(1.0E-6);
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.defaultMinimalIterationCount = 3;
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.minimalIterationCount = defaultMinimalIterationCount;
		verifyIterationCount();
	}

	public double getResult() throws java.lang.IllegalStateException {
		if (resultComputed) {
			return result;
		} else {
			throw org.apache.commons.math.MathRuntimeException.createIllegalStateException(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE);
		}
	}

	protected final void setResult(double newResult, int iterationCount) {
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.result = newResult;
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.iterationCount = iterationCount;
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.resultComputed = true;
	}

	protected final void clearResult() {
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.iterationCount = 0;
		org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl.this.resultComputed = false;
	}

	public void setMinimalIterationCount(int count) {
		minimalIterationCount = count;
	}

	public int getMinimalIterationCount() {
		return minimalIterationCount;
	}

	public void resetMinimalIterationCount() {
		minimalIterationCount = defaultMinimalIterationCount;
	}

	protected void verifyInterval(double lower, double upper) throws java.lang.IllegalArgumentException {
		if (lower >= upper) {
			throw org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL, lower, upper);
		} 
	}

	protected void verifyIterationCount() throws java.lang.IllegalArgumentException {
		if (((minimalIterationCount) <= 0) || ((maximalIterationCount) <= (minimalIterationCount))) {
			throw org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS, minimalIterationCount, maximalIterationCount);
		} 
	}
}

