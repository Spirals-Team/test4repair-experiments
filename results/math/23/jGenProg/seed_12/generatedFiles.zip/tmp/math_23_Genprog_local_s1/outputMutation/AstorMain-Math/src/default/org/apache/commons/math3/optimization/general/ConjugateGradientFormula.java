package org.apache.commons.math3.optimization.general;


public enum ConjugateGradientFormula {
FLETCHER_REEVES, POLAK_RIBIERE;}

