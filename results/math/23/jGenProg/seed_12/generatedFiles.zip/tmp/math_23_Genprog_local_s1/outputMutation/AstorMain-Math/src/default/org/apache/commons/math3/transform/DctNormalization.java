package org.apache.commons.math3.transform;


public enum DctNormalization {
STANDARD_DCT_I, ORTHOGONAL_DCT_I;}

