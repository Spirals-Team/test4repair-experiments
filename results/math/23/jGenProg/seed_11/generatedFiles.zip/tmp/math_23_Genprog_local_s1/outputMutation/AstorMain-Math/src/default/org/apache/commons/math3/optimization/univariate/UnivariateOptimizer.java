package org.apache.commons.math3.optimization.univariate;


public interface UnivariateOptimizer extends org.apache.commons.math3.optimization.univariate.BaseUnivariateOptimizer<org.apache.commons.math3.analysis.UnivariateFunction> {}

