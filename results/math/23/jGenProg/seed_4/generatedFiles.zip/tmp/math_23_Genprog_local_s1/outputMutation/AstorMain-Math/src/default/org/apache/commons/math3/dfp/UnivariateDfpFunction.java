package org.apache.commons.math3.dfp;


public interface UnivariateDfpFunction {
	org.apache.commons.math3.dfp.Dfp value(org.apache.commons.math3.dfp.Dfp x);
}

