package org.apache.commons.math3.geometry.partitioning;


public enum Side {
PLUS, MINUS, BOTH, HYPER;}

