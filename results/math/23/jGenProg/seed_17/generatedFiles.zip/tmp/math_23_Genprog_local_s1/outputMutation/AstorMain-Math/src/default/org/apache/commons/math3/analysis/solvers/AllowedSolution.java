package org.apache.commons.math3.analysis.solvers;


public enum AllowedSolution {
ANY_SIDE, LEFT_SIDE, RIGHT_SIDE, BELOW_SIDE, ABOVE_SIDE;}

