package org.apache.commons.math.analysis;


public interface UnivariateVectorFunction {
	double[] value(double x);
}

