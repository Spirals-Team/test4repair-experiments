package org.apache.commons.math.dfp;


public interface UnivariateDfpFunction {
	org.apache.commons.math.dfp.Dfp value(org.apache.commons.math.dfp.Dfp x);
}

