package org.apache.commons.math.analysis;


public interface DifferentiableUnivariateFunction extends org.apache.commons.math.analysis.UnivariateFunction {
	org.apache.commons.math.analysis.UnivariateFunction derivative();
}

