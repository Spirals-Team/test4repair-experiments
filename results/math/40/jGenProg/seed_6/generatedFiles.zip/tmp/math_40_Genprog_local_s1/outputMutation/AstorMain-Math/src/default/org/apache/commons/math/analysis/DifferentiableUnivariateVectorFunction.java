package org.apache.commons.math.analysis;


public interface DifferentiableUnivariateVectorFunction extends org.apache.commons.math.analysis.UnivariateVectorFunction {
	org.apache.commons.math.analysis.UnivariateVectorFunction derivative();
}

