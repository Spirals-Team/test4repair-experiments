package org.apache.commons.math.analysis;


public interface UnivariateMatrixFunction {
	double[][] value(double x);
}

