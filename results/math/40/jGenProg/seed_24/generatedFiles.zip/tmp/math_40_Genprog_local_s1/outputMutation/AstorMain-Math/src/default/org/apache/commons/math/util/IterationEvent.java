package org.apache.commons.math.util;


public class IterationEvent extends java.util.EventObject {
	private static final long serialVersionUID = -1405936936084001482L;

	public IterationEvent(final java.lang.Object source) {
		super(source);
	}
}

