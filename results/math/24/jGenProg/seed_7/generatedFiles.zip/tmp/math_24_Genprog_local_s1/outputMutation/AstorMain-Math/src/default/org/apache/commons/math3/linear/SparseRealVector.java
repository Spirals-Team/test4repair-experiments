package org.apache.commons.math3.linear;


public abstract class SparseRealVector extends org.apache.commons.math3.linear.RealVector {}

