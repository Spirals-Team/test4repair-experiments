package org.apache.commons.math3.linear;


public interface SparseRealMatrix extends org.apache.commons.math3.linear.RealMatrix {}

