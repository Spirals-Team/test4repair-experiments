package org.apache.commons.math3.optimization;


public enum GoalType implements java.io.Serializable {
MAXIMIZE, MINIMIZE;}

