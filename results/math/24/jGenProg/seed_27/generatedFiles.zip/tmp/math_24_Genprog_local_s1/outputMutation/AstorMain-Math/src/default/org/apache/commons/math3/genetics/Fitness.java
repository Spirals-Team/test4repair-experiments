package org.apache.commons.math3.genetics;


public interface Fitness {
	double fitness();
}

