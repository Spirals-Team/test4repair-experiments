package org.apache.commons.math3.analysis.solvers;


public interface PolynomialSolver extends org.apache.commons.math3.analysis.solvers.BaseUnivariateSolver<org.apache.commons.math3.analysis.polynomials.PolynomialFunction> {}

