package org.apache.commons.math3.optimization;


public interface MultivariateOptimizer extends org.apache.commons.math3.optimization.BaseMultivariateOptimizer<org.apache.commons.math3.analysis.MultivariateFunction> {}

