package org.apache.commons.math.random;


public class JDKRandomGenerator extends java.util.Random implements org.apache.commons.math.random.RandomGenerator {
	private static final long serialVersionUID = -3561898582944940550L;
}

