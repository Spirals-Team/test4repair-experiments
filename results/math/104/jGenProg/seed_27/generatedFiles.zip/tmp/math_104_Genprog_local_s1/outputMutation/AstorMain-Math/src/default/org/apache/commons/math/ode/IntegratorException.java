package org.apache.commons.math.ode;


public class IntegratorException extends org.apache.commons.math.MathException {
	public IntegratorException(java.lang.String specifier ,java.lang.String[] parts) {
		super(specifier, parts);
	}

	private static final long serialVersionUID = -1390328069787882608L;
}

