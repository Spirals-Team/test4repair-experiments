package org.apache.commons.math.analysis;


public interface DifferentiableUnivariateRealFunction extends org.apache.commons.math.analysis.UnivariateRealFunction {
	public org.apache.commons.math.analysis.UnivariateRealFunction derivative();
}

