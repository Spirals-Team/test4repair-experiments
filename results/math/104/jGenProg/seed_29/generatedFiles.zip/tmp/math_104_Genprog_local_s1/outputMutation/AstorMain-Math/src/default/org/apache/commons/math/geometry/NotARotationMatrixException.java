package org.apache.commons.math.geometry;


public class NotARotationMatrixException extends org.apache.commons.math.MathException {
	public NotARotationMatrixException(java.lang.String specifier ,java.lang.String[] parts) {
		super(specifier, parts);
	}

	private static final long serialVersionUID = 5647178478658937642L;
}

