package org.apache.commons.math.linear;


public interface QRDecomposition {
	public abstract org.apache.commons.math.linear.RealMatrix getR();

	public abstract org.apache.commons.math.linear.RealMatrix getQ();
}

