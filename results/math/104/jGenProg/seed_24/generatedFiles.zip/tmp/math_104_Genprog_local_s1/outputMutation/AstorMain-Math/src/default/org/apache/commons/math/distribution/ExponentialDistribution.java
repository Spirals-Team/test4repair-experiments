package org.apache.commons.math.distribution;


public interface ExponentialDistribution extends org.apache.commons.math.distribution.ContinuousDistribution {
	void setMean(double mean);

	double getMean();
}

