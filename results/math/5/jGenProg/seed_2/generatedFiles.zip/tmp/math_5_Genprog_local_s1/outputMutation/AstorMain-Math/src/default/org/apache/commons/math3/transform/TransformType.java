package org.apache.commons.math3.transform;


public enum TransformType {
FORWARD, INVERSE;}

