package org.apache.commons.math3.linear;


@java.lang.Deprecated
public interface SparseRealMatrix extends org.apache.commons.math3.linear.RealMatrix {}

