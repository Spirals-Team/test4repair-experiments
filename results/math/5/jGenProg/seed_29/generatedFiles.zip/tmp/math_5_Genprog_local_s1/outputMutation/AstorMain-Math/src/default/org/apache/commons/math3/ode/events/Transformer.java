package org.apache.commons.math3.ode.events;


enum Transformer {
UNINITIALIZED {
		protected double transformed(final double g) {
			return 0;
		}
	}, PLUS {
		protected double transformed(final double g) {
			return g;
		}
	}, MINUS {
		protected double transformed(final double g) {
			return -g;
		}
	}, MIN {
		protected double transformed(final double g) {
			return org.apache.commons.math3.util.FastMath.min((-(org.apache.commons.math3.util.Precision.SAFE_MIN)), org.apache.commons.math3.util.FastMath.min((-g), (+g)));
		}
	}, MAX {
		protected double transformed(final double g) {
			return org.apache.commons.math3.util.FastMath.max((+(org.apache.commons.math3.util.Precision.SAFE_MIN)), org.apache.commons.math3.util.FastMath.max((-g), (+g)));
		}
	};
	protected abstract double transformed(double g);
}

