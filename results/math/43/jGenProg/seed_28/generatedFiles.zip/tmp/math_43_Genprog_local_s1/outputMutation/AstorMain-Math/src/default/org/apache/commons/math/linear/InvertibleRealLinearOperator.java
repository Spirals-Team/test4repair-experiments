package org.apache.commons.math.linear;


public abstract class InvertibleRealLinearOperator extends org.apache.commons.math.linear.RealLinearOperator {
	public abstract org.apache.commons.math.linear.RealVector solve(final org.apache.commons.math.linear.RealVector b);
}

