package org.apache.commons.math.optimization.direct;


public abstract class BaseAbstractSimpleBoundsScalarOptimizer<FUNC extends org.apache.commons.math.analysis.MultivariateRealFunction> extends org.apache.commons.math.optimization.direct.BaseAbstractScalarOptimizer<FUNC> implements org.apache.commons.math.optimization.BaseMultivariateRealOptimizer<FUNC> , org.apache.commons.math.optimization.BaseSimpleBoundsMultivariateRealOptimizer<FUNC> {
	private double[] lowerBound;

	private double[] upperBound;

	protected BaseAbstractSimpleBoundsScalarOptimizer() {
	}

	protected BaseAbstractSimpleBoundsScalarOptimizer(org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.RealPointValuePair> checker) {
		super(checker);
	}

	public double[] getLowerBound() {
		return lowerBound.clone();
	}

	public double[] getUpperBound() {
		return upperBound.clone();
	}

	public org.apache.commons.math.optimization.RealPointValuePair optimize(int maxEval, FUNC f, org.apache.commons.math.optimization.GoalType goalType, double[] startPoint) {
		return optimize(maxEval, f, goalType, startPoint, null, null);
	}

	public org.apache.commons.math.optimization.RealPointValuePair optimize(int maxEval, FUNC f, org.apache.commons.math.optimization.GoalType goalType, double[] startPoint, double[] lower, double[] upper) {
		final int dim = startPoint.length;
		if (lower != null) {
			if ((lower.length) != dim) {
				throw new org.apache.commons.math.exception.DimensionMismatchException(lower.length , dim);
			} 
			for (int i = 0 ; i < dim ; i++) {
				final double v = startPoint[i];
				final double lo = lower[i];
				if (v < lo) {
					throw new org.apache.commons.math.exception.NumberIsTooSmallException(v , lo , true);
				} 
			}
		} 
		if (upper != null) {
			if ((upper.length) != dim) {
				throw new org.apache.commons.math.exception.DimensionMismatchException(upper.length , dim);
			} 
			for (int i = 0 ; i < dim ; i++) {
				final double v = startPoint[i];
				final double hi = upper[i];
				if (v > hi) {
					throw new org.apache.commons.math.exception.NumberIsTooLargeException(v , hi , true);
				} 
			}
		} 
		if (lower == null) {
			lowerBound = new double[dim];
			for (int i = 0 ; i < dim ; i++) {
				lowerBound[i] = java.lang.Double.NEGATIVE_INFINITY;
			}
		} else {
			lowerBound = lower.clone();
		}
		if (upper == null) {
			upperBound = new double[dim];
			for (int i = 0 ; i < dim ; i++) {
				upperBound[i] = java.lang.Double.POSITIVE_INFINITY;
			}
		} else {
			upperBound = upper.clone();
		}
		return super.optimize(maxEval, f, goalType, startPoint);
	}
}

