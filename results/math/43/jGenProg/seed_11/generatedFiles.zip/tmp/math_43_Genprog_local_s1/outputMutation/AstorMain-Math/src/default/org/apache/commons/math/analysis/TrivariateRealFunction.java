package org.apache.commons.math.analysis;


public interface TrivariateRealFunction {
	double value(double x, double y, double z);
}

