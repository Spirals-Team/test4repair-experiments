package org.apache.commons.math3.analysis.differentiation;


public interface UnivariateFunctionDifferentiator {
	org.apache.commons.math3.analysis.differentiation.UnivariateDifferentiableFunction differentiate(org.apache.commons.math3.analysis.UnivariateFunction function);
}

