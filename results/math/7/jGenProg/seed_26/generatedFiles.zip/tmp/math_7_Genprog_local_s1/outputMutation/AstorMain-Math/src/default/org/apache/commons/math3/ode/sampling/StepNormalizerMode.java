package org.apache.commons.math3.ode.sampling;


public enum StepNormalizerMode {
INCREMENT, MULTIPLES;}

