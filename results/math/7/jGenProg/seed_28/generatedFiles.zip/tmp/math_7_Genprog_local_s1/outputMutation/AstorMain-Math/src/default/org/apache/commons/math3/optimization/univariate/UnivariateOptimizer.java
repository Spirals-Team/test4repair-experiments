package org.apache.commons.math3.optimization.univariate;


@java.lang.Deprecated
public interface UnivariateOptimizer extends org.apache.commons.math3.optimization.univariate.BaseUnivariateOptimizer<org.apache.commons.math3.analysis.UnivariateFunction> {}

