package org.apache.commons.math3.analysis.function;


public class Divide implements org.apache.commons.math3.analysis.BivariateFunction {
	public double value(double x, double y) {
		return x / y;
	}
}

