package org.apache.commons.math.estimation;


public class EstimationException extends org.apache.commons.math.MathException {
	private static final long serialVersionUID = -573038581493881337L;

	public EstimationException(java.lang.String specifier ,java.lang.Object[] parts) {
		super(specifier, parts);
	}
}

