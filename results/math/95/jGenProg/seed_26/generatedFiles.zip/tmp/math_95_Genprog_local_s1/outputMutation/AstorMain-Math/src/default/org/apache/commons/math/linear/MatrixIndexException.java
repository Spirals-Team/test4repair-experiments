package org.apache.commons.math.linear;


public class MatrixIndexException extends java.lang.RuntimeException {
	private static final long serialVersionUID = 3728473373420246054L;

	public MatrixIndexException(java.lang.String message) {
		super(message);
	}
}

