package org.apache.commons.math.random;


public interface RandomVectorGenerator {
	public double[] nextVector();
}

