package org.apache.commons.math.genetics;


public interface Chromosome {
	org.apache.commons.math.genetics.Fitness getFitness();
}

