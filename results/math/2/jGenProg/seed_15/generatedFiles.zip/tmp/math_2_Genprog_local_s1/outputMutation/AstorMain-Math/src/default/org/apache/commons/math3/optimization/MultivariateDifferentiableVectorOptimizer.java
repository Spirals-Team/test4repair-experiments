package org.apache.commons.math3.optimization;


@java.lang.Deprecated
public interface MultivariateDifferentiableVectorOptimizer extends org.apache.commons.math3.optimization.BaseMultivariateVectorOptimizer<org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction> {}

