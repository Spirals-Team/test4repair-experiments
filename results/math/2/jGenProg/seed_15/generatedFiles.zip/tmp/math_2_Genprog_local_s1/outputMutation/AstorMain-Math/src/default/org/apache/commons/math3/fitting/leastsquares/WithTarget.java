package org.apache.commons.math3.fitting.leastsquares;


public interface WithTarget<T> {
	T withTarget(double[] target);
}

