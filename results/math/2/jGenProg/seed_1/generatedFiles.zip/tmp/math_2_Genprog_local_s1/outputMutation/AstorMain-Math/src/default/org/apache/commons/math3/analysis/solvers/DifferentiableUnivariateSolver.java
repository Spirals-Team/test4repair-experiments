package org.apache.commons.math3.analysis.solvers;


@java.lang.Deprecated
public interface DifferentiableUnivariateSolver extends org.apache.commons.math3.analysis.solvers.BaseUnivariateSolver<org.apache.commons.math3.analysis.DifferentiableUnivariateFunction> {}

