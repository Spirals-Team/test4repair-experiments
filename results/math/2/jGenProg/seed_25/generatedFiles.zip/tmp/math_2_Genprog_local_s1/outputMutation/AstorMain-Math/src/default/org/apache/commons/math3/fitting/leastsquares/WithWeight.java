package org.apache.commons.math3.fitting.leastsquares;


public interface WithWeight<T> {
	T withWeight(org.apache.commons.math3.linear.RealMatrix weight);
}

