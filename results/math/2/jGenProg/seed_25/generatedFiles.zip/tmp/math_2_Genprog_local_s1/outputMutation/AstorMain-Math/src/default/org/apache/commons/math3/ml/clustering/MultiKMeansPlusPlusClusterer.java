package org.apache.commons.math3.ml.clustering;


public class MultiKMeansPlusPlusClusterer<T extends org.apache.commons.math3.ml.clustering.Clusterable> extends org.apache.commons.math3.ml.clustering.Clusterer<T> {
	private final org.apache.commons.math3.ml.clustering.KMeansPlusPlusClusterer<T> clusterer;

	private final int numTrials;

	public MultiKMeansPlusPlusClusterer(final org.apache.commons.math3.ml.clustering.KMeansPlusPlusClusterer<T> clusterer ,final int numTrials) {
		super(clusterer.getDistanceMeasure());
		this.clusterer = clusterer;
		this.numTrials = numTrials;
	}

	public org.apache.commons.math3.ml.clustering.KMeansPlusPlusClusterer<T> getClusterer() {
		return clusterer;
	}

	public int getNumTrials() {
		return numTrials;
	}

	@java.lang.Override
	public java.util.List<org.apache.commons.math3.ml.clustering.CentroidCluster<T>> cluster(final java.util.Collection<T> points) throws org.apache.commons.math3.exception.ConvergenceException, org.apache.commons.math3.exception.MathIllegalArgumentException {
		java.util.List<org.apache.commons.math3.ml.clustering.CentroidCluster<T>> best = null;
		double bestVarianceSum = java.lang.Double.POSITIVE_INFINITY;
		for (int i = 0 ; i < (numTrials) ; ++i) {
			java.util.List<org.apache.commons.math3.ml.clustering.CentroidCluster<T>> clusters = clusterer.cluster(points);
			double varianceSum = 0.0;
			for (final org.apache.commons.math3.ml.clustering.CentroidCluster<T> cluster : clusters) {
				if (!(cluster.getPoints().isEmpty())) {
					final org.apache.commons.math3.ml.clustering.Clusterable center = cluster.getCenter();
					final org.apache.commons.math3.stat.descriptive.moment.Variance stat = new org.apache.commons.math3.stat.descriptive.moment.Variance();
					for (final T point : cluster.getPoints()) {
						stat.increment(distance(point, center));
					}
					varianceSum += stat.getResult();
				} 
			}
			if (varianceSum <= bestVarianceSum) {
				best = clusters;
				bestVarianceSum = varianceSum;
			} 
		}
		return best;
	}
}

