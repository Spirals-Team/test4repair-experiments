package org.apache.commons.math3.transform;


public enum DftNormalization {
STANDARD, UNITARY;}

