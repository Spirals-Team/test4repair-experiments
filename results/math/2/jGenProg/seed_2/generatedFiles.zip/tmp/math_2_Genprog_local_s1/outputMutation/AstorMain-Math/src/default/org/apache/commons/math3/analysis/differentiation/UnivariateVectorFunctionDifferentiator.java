package org.apache.commons.math3.analysis.differentiation;


public interface UnivariateVectorFunctionDifferentiator {
	org.apache.commons.math3.analysis.differentiation.UnivariateDifferentiableVectorFunction differentiate(org.apache.commons.math3.analysis.UnivariateVectorFunction function);
}

