package org.apache.commons.math3.analysis;


@java.lang.Deprecated
public interface DifferentiableUnivariateVectorFunction extends org.apache.commons.math3.analysis.UnivariateVectorFunction {
	org.apache.commons.math3.analysis.UnivariateVectorFunction derivative();
}

