package org.apache.commons.math3.ml.clustering;


public interface Clusterable {
	double[] getPoint();
}

