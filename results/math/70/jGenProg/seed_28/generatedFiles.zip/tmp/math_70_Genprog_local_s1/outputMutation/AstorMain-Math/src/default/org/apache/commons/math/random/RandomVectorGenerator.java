package org.apache.commons.math.random;


public interface RandomVectorGenerator {
	double[] nextVector();
}

