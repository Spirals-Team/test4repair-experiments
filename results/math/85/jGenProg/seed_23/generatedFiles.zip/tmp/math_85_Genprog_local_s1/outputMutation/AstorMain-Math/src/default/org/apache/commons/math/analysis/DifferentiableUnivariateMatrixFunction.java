package org.apache.commons.math.analysis;


public interface DifferentiableUnivariateMatrixFunction extends org.apache.commons.math.analysis.UnivariateMatrixFunction {
	public org.apache.commons.math.analysis.UnivariateMatrixFunction derivative();
}

