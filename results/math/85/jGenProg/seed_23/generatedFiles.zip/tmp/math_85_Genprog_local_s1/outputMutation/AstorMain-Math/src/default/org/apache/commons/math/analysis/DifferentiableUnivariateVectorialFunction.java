package org.apache.commons.math.analysis;


public interface DifferentiableUnivariateVectorialFunction extends org.apache.commons.math.analysis.UnivariateVectorialFunction {
	public org.apache.commons.math.analysis.UnivariateVectorialFunction derivative();
}

