package org.apache.commons.math.optimization.general;


public class GaussNewtonOptimizer extends org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer {
	private final boolean useLU;

	public GaussNewtonOptimizer(final boolean useLU) {
		this.useLU = useLU;
	}

	@java.lang.Override
	public org.apache.commons.math.optimization.VectorialPointValuePair doOptimize() throws org.apache.commons.math.exception.MathUserException {
		final org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> checker = getConvergenceChecker();
		org.apache.commons.math.optimization.VectorialPointValuePair current = null;
		int iter = 0;
		for (boolean converged = false ; !converged ; ) {
			++iter;
			org.apache.commons.math.optimization.VectorialPointValuePair previous = current;
			updateResidualsAndCost();
			updateJacobian();
			current = new org.apache.commons.math.optimization.VectorialPointValuePair(point , objective);
			final double[] targetValues = getTargetRef();
			final double[] residualsWeights = getWeightRef();
			final double[] b = new double[cols];
			final double[][] a = new double[cols][cols];
			for (int i = 0 ; i < (rows) ; ++i) {
				final double[] grad = weightedResidualJacobian[i];
				final double weight = residualsWeights[i];
				final double residual = (objective[i]) - (targetValues[i]);
				final double wr = weight * residual;
				for (int j = 0 ; j < (cols) ; ++j) {
					b[j] += wr * (grad[j]);
				}
				for (int k = 0 ; k < (cols) ; ++k) {
					double[] ak = a[k];
					double wgk = weight * (grad[k]);
					for (int l = 0 ; l < (cols) ; ++l) {
						ak[l] += wgk * (grad[l]);
					}
				}
			}
			try {
				org.apache.commons.math.linear.RealMatrix mA = new org.apache.commons.math.linear.BlockRealMatrix(a);
				org.apache.commons.math.linear.DecompositionSolver solver = useLU ? new org.apache.commons.math.linear.LUDecompositionImpl(mA).getSolver() : new org.apache.commons.math.linear.QRDecompositionImpl(mA).getSolver();
				final double[] dX = solver.solve(b);
				for (int i = 0 ; i < (cols) ; ++i) {
					point[i] += dX[i];
				}
			} catch (org.apache.commons.math.linear.SingularMatrixException e) {
				throw new org.apache.commons.math.exception.ConvergenceException(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM);
			}
			if (checker != null) {
				if (previous != null) {
					converged = checker.converged(iter, previous, current);
				} 
			} 
		}
		return current;
	}
}

