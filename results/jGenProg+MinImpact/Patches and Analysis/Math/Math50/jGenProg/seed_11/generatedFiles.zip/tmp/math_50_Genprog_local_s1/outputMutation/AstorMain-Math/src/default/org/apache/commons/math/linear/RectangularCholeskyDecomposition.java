package org.apache.commons.math.linear;


public interface RectangularCholeskyDecomposition {
	org.apache.commons.math.linear.RealMatrix getRootMatrix();

	int getRank();
}

