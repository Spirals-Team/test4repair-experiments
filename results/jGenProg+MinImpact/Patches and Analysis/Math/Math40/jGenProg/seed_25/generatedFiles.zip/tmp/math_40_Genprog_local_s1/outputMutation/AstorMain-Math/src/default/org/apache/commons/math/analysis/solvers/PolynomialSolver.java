package org.apache.commons.math.analysis.solvers;


public interface PolynomialSolver extends org.apache.commons.math.analysis.solvers.BaseUnivariateRealSolver<org.apache.commons.math.analysis.polynomials.PolynomialFunction> {}

