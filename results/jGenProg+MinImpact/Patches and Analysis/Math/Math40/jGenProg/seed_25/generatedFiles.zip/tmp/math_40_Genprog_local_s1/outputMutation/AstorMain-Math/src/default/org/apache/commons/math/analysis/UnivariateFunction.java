package org.apache.commons.math.analysis;


public interface UnivariateFunction {
	double value(double x);
}

