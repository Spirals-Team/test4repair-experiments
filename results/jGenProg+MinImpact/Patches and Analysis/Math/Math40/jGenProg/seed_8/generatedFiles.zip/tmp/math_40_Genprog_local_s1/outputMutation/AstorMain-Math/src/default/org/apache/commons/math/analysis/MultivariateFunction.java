package org.apache.commons.math.analysis;


public interface MultivariateFunction {
	double value(double[] point);
}

