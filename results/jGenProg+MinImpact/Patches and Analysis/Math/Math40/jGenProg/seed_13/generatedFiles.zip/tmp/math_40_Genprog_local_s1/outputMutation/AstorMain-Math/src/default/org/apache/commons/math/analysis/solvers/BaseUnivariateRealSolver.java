package org.apache.commons.math.analysis.solvers;


public interface BaseUnivariateRealSolver<FUNC extends org.apache.commons.math.analysis.UnivariateFunction> {
	int getMaxEvaluations();

	int getEvaluations();

	double getAbsoluteAccuracy();

	double getRelativeAccuracy();

	double getFunctionValueAccuracy();

	double solve(int maxEval, FUNC f, double min, double max);

	double solve(int maxEval, FUNC f, double min, double max, double startValue);

	double solve(int maxEval, FUNC f, double startValue);
}

