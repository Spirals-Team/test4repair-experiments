package org.apache.commons.math.optimization;


public interface DifferentiableMultivariateVectorialOptimizer extends org.apache.commons.math.optimization.BaseMultivariateVectorialOptimizer<org.apache.commons.math.analysis.DifferentiableMultivariateVectorFunction> {}

