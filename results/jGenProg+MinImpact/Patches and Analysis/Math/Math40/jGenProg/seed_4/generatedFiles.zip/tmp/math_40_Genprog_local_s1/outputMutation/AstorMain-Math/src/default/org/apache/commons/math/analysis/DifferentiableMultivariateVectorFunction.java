package org.apache.commons.math.analysis;


public interface DifferentiableMultivariateVectorFunction extends org.apache.commons.math.analysis.MultivariateVectorFunction {
	org.apache.commons.math.analysis.MultivariateMatrixFunction jacobian();
}

