package org.apache.commons.math3.util;


public interface NumberTransformer {
	double transform(java.lang.Object o) throws org.apache.commons.math3.exception.MathIllegalArgumentException;
}

