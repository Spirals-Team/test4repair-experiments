package org.apache.commons.math3.analysis.solvers;


public interface UnivariateSolver extends org.apache.commons.math3.analysis.solvers.BaseUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> {}

