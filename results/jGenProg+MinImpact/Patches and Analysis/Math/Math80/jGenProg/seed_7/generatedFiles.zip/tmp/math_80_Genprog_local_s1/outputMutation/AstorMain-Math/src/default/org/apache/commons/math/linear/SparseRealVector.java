package org.apache.commons.math.linear;


public interface SparseRealVector extends org.apache.commons.math.linear.RealVector {}

