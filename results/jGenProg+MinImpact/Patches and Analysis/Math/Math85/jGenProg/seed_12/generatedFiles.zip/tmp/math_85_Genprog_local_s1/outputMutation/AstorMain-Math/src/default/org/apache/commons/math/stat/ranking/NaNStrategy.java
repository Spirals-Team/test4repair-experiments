package org.apache.commons.math.stat.ranking;


public enum NaNStrategy {
MINIMAL, MAXIMAL, REMOVED, FIXED;}

