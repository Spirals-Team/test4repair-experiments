package org.apache.commons.math3.optimization;


@java.lang.Deprecated
public interface OptimizationData {}

