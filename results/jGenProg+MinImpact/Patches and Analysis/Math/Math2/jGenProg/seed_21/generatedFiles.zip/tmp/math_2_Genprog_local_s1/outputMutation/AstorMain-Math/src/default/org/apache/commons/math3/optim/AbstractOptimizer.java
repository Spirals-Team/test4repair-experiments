package org.apache.commons.math3.optim;


public abstract class AbstractOptimizer<PAIR, OPTIM extends org.apache.commons.math3.optim.AbstractOptimizer<PAIR, OPTIM>> implements org.apache.commons.math3.fitting.leastsquares.WithConvergenceChecker<PAIR, OPTIM> , org.apache.commons.math3.fitting.leastsquares.WithMaxEvaluations<OPTIM> , org.apache.commons.math3.fitting.leastsquares.WithMaxIterations<OPTIM> {
	private org.apache.commons.math3.util.Incrementor evaluations = new org.apache.commons.math3.util.Incrementor(java.lang.Integer.MAX_VALUE , new org.apache.commons.math3.optim.AbstractOptimizer.MaxEvalCallback());

	private org.apache.commons.math3.util.Incrementor iterations = new org.apache.commons.math3.util.Incrementor(java.lang.Integer.MAX_VALUE , new org.apache.commons.math3.optim.AbstractOptimizer.MaxIterCallback());

	private org.apache.commons.math3.optim.ConvergenceChecker<PAIR> checker = null;

	protected AbstractOptimizer() {
	}

	protected AbstractOptimizer(org.apache.commons.math3.optim.AbstractOptimizer other) {
		checker = other.checker;
		evaluations.setMaximalCount(other.getMaxEvaluations());
		iterations.setMaximalCount(other.getMaxIterations());
	}

	protected OPTIM self() {
		final OPTIM optim = ((OPTIM)(org.apache.commons.math3.optim.AbstractOptimizer.this));
		return optim;
	}

	public OPTIM withConvergenceChecker(org.apache.commons.math3.optim.ConvergenceChecker<PAIR> checker) {
		org.apache.commons.math3.optim.AbstractOptimizer.this.checker = checker;
		return self();
	}

	public OPTIM withMaxEvaluations(int max) {
		evaluations.setMaximalCount(max);
		return self();
	}

	public OPTIM withMaxIterations(int max) {
		iterations.setMaximalCount(max);
		return self();
	}

	public int getMaxEvaluations() {
		return evaluations.getMaximalCount();
	}

	public int getEvaluations() {
		return evaluations.getCount();
	}

	public int getMaxIterations() {
		return iterations.getMaximalCount();
	}

	public int getIterations() {
		return iterations.getCount();
	}

	public org.apache.commons.math3.optim.ConvergenceChecker<PAIR> getConvergenceChecker() {
		return checker;
	}

	public PAIR optimize() throws org.apache.commons.math3.exception.TooManyEvaluationsException, org.apache.commons.math3.exception.TooManyIterationsException {
		evaluations.resetCount();
		iterations.resetCount();
		return doOptimize();
	}

	protected abstract PAIR doOptimize();

	protected void incrementEvaluationCount() throws org.apache.commons.math3.exception.TooManyEvaluationsException {
		evaluations.incrementCount();
	}

	protected void incrementIterationCount() throws org.apache.commons.math3.exception.TooManyIterationsException {
		iterations.incrementCount();
	}

	private static class MaxEvalCallback implements org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback {
		public void trigger(int max) {
			throw new org.apache.commons.math3.exception.TooManyEvaluationsException(max);
		}
	}

	private static class MaxIterCallback implements org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback {
		public void trigger(int max) {
			throw new org.apache.commons.math3.exception.TooManyIterationsException(max);
		}
	}
}

