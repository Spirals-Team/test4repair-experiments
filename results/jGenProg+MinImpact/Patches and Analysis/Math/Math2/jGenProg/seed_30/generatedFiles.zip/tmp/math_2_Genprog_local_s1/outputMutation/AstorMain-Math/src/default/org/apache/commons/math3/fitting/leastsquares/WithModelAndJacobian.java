package org.apache.commons.math3.fitting.leastsquares;


public interface WithModelAndJacobian<T> {
	T withModelAndJacobian(org.apache.commons.math3.analysis.MultivariateVectorFunction model, org.apache.commons.math3.analysis.MultivariateMatrixFunction jacobian);
}

