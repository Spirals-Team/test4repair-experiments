package org.apache.commons.math3.analysis;


@java.lang.Deprecated
public interface DifferentiableUnivariateMatrixFunction extends org.apache.commons.math3.analysis.UnivariateMatrixFunction {
	org.apache.commons.math3.analysis.UnivariateMatrixFunction derivative();
}

