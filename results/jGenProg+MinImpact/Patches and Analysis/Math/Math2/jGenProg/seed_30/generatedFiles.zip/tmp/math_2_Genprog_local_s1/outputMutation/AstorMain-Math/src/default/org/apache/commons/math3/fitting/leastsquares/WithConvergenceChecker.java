package org.apache.commons.math3.fitting.leastsquares;


public interface WithConvergenceChecker<PAIR, T> {
	T withConvergenceChecker(org.apache.commons.math3.optim.ConvergenceChecker<PAIR> checker);
}

