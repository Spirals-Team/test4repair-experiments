package org.apache.commons.math3.optim.nonlinear.scalar;


public enum GoalType implements org.apache.commons.math3.optim.OptimizationData {
MAXIMIZE, MINIMIZE;}

