package org.apache.commons.math3.fitting.leastsquares;


public interface WithMaxEvaluations<T> {
	T withMaxEvaluations(int maxEval);
}

