package org.apache.commons.math3.fitting.leastsquares;


public interface WithStartPoint<T> {
	T withStartPoint(double[] start);
}

