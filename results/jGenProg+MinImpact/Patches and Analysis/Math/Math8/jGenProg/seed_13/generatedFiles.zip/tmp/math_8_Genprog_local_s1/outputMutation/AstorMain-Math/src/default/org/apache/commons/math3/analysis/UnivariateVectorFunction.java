package org.apache.commons.math3.analysis;


public interface UnivariateVectorFunction {
	double[] value(double x);
}

