package org.apache.commons.math3.genetics;


public class InvalidRepresentationException extends org.apache.commons.math3.exception.MathIllegalArgumentException {
	private static final long serialVersionUID = 1L;

	public InvalidRepresentationException(org.apache.commons.math3.exception.util.Localizable pattern ,java.lang.Object... args) {
		super(pattern, args);
	}
}

