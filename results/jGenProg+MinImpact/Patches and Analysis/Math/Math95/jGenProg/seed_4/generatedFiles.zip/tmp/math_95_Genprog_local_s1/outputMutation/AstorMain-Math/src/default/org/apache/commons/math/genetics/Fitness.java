package org.apache.commons.math.genetics;


public interface Fitness extends java.lang.Comparable {}

