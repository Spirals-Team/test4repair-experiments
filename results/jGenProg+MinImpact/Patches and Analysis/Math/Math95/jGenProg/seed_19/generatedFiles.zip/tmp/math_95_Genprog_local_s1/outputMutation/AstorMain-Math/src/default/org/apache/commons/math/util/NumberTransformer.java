package org.apache.commons.math.util;


public interface NumberTransformer extends java.io.Serializable {
	double transform(java.lang.Object o) throws org.apache.commons.math.MathException;
}

