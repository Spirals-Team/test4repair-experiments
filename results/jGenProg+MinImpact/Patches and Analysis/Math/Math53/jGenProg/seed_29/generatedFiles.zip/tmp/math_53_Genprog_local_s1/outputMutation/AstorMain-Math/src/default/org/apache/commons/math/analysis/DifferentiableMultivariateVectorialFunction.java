package org.apache.commons.math.analysis;


public interface DifferentiableMultivariateVectorialFunction extends org.apache.commons.math.analysis.MultivariateVectorialFunction {
	org.apache.commons.math.analysis.MultivariateMatrixFunction jacobian();
}

