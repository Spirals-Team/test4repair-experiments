package org.apache.commons.math.distribution;


public interface ExponentialDistribution extends org.apache.commons.math.distribution.ContinuousDistribution {
	double getMean();
}

