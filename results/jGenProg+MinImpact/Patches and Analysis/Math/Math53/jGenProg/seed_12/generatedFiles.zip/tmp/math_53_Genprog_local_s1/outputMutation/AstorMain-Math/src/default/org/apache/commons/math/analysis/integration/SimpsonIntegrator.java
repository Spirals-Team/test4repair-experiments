package org.apache.commons.math.analysis.integration;


public class SimpsonIntegrator extends org.apache.commons.math.analysis.integration.UnivariateRealIntegratorImpl {
	public SimpsonIntegrator() {
		super(64);
	}

	public double integrate(final org.apache.commons.math.analysis.UnivariateRealFunction f, final double min, final double max) throws java.lang.IllegalArgumentException, org.apache.commons.math.exception.MathUserException, org.apache.commons.math.exception.MaxCountExceededException {
		clearResult();
		verifyInterval(min, max);
		verifyIterationCount();
		org.apache.commons.math.analysis.integration.TrapezoidIntegrator qtrap = new org.apache.commons.math.analysis.integration.TrapezoidIntegrator();
		if ((minimalIterationCount) == 1) {
			final double s = ((4 * (qtrap.stage(f, min, max, 1))) - (qtrap.stage(f, min, max, 0))) / 3.0;
			setResult(s, 1);
			return result;
		} 
		double olds = 0;
		double oldt = qtrap.stage(f, min, max, 0);
		for (int i = 1 ; i <= (maximalIterationCount) ; ++i) {
			final double t = qtrap.stage(f, min, max, i);
			final double s = ((4 * t) - oldt) / 3.0;
			if (i >= (minimalIterationCount)) {
				final double delta = org.apache.commons.math.util.FastMath.abs((s - olds));
				final double rLimit = ((relativeAccuracy) * ((org.apache.commons.math.util.FastMath.abs(olds)) + (org.apache.commons.math.util.FastMath.abs(s)))) * 0.5;
				if ((delta <= rLimit) || (delta <= (absoluteAccuracy))) {
					setResult(s, i);
					return result;
				} 
			} 
			olds = s;
			oldt = t;
		}
		throw new org.apache.commons.math.exception.MaxCountExceededException(maximalIterationCount);
	}

	@java.lang.Override
	protected void verifyIterationCount() throws java.lang.IllegalArgumentException {
		super.verifyIterationCount();
		if ((maximalIterationCount) > 64) {
			throw org.apache.commons.math.MathRuntimeException.createIllegalArgumentException(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS, 0, 64);
		} 
	}
}

