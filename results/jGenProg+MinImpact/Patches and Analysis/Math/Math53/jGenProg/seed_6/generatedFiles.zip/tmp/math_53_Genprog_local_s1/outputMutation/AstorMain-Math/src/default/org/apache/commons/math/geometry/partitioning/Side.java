package org.apache.commons.math.geometry.partitioning;


public enum Side {
PLUS, MINUS, BOTH, HYPER;}

