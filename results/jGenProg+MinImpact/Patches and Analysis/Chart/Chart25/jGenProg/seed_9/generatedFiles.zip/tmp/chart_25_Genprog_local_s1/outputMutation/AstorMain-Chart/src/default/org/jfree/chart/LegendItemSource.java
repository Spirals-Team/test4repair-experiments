package org.jfree.chart;


public interface LegendItemSource {
	public org.jfree.chart.LegendItemCollection getLegendItems();
}

