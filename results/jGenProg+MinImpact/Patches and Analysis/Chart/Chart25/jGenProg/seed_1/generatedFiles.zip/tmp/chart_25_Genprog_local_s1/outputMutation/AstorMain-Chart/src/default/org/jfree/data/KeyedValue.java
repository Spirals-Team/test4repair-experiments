package org.jfree.data;


public interface KeyedValue extends org.jfree.data.Value {
	public java.lang.Comparable getKey();
}

