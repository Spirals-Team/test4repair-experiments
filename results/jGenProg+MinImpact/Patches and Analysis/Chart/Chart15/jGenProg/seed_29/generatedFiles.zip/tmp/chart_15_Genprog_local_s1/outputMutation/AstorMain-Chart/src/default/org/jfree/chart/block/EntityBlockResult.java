package org.jfree.chart.block;


public interface EntityBlockResult {
	public org.jfree.chart.entity.EntityCollection getEntityCollection();
}

