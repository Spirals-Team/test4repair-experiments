package org.jfree.chart.plot;


public class XYCrosshairState extends org.jfree.chart.plot.CrosshairState {
	public XYCrosshairState() {
	}
}

