package org.jfree.data.general;


public interface DatasetChangeListener extends java.util.EventListener {
	public void datasetChanged(org.jfree.data.general.DatasetChangeEvent event);
}

