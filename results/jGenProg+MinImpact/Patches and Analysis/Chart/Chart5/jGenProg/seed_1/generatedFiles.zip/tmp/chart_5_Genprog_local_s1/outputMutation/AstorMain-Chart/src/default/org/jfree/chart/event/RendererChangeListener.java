package org.jfree.chart.event;


public interface RendererChangeListener extends java.util.EventListener {
	public void rendererChanged(org.jfree.chart.event.RendererChangeEvent event);
}

