package org.jfree.chart.plot;


public interface ValueAxisPlot {
	public org.jfree.data.Range getDataRange(org.jfree.chart.axis.ValueAxis axis);
}

