package org.jfree.chart.plot.dial;


public interface DialLayerChangeListener extends java.util.EventListener {
	public void dialLayerChanged(org.jfree.chart.plot.dial.DialLayerChangeEvent event);
}

