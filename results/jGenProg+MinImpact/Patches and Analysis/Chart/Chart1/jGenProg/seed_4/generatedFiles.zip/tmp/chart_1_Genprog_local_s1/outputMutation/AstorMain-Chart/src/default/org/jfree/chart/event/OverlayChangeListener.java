package org.jfree.chart.event;


public interface OverlayChangeListener extends java.util.EventListener {
	public void overlayChanged(org.jfree.chart.event.OverlayChangeEvent event);
}

