package org.jfree.data.pie;


public interface PieDataset extends org.jfree.data.KeyedValues , org.jfree.data.general.Dataset {
	public org.jfree.data.pie.PieDatasetSelectionState getSelectionState();
}

