package org.jfree.data.category;


public interface CategoryRangeInfo {
	public org.jfree.data.Range getRangeBounds(java.util.List visibleSeriesKeys, boolean includeInterval);
}

