package org.jfree.data.pie;


public interface SelectablePieDataset {
	public org.jfree.data.pie.PieDatasetSelectionState getSelectionState();
}

