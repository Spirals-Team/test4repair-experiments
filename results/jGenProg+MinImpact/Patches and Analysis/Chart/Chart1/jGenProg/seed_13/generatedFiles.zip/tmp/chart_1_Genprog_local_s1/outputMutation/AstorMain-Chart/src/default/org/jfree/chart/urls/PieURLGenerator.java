package org.jfree.chart.urls;


public interface PieURLGenerator {
	public java.lang.String generateURL(org.jfree.data.pie.PieDataset dataset, java.lang.Comparable key, int pieIndex);
}

