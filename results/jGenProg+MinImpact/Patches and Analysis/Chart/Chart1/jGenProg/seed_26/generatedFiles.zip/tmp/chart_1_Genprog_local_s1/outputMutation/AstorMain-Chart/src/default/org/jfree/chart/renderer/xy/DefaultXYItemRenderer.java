package org.jfree.chart.renderer.xy;


public class DefaultXYItemRenderer extends org.jfree.chart.renderer.xy.XYLineAndShapeRenderer implements java.io.Serializable {
	static final long serialVersionUID = 3450423530996888074L;
}

