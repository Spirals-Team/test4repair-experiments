package org.jfree.data.xy;


public interface XYDomainInfo {
	public org.jfree.data.Range getDomainBounds(java.util.List visibleSeriesKeys, boolean includeInterval);
}

