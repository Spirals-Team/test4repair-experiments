package org.jfree.data.category;


public interface SelectableCategoryDataset {
	public org.jfree.data.category.CategoryDatasetSelectionState getSelectionState();
}

