package org.jfree.data.event;


public interface DatasetChangeListener extends java.util.EventListener {
	public void datasetChanged(org.jfree.data.event.DatasetChangeEvent event);
}

