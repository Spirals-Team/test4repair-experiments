package org.jfree.chart.event;


public interface ChartProgressListener extends java.util.EventListener {
	public void chartProgress(org.jfree.chart.event.ChartProgressEvent event);
}

