package org.jfree.data.general;


public interface DatasetSelectionState {}

