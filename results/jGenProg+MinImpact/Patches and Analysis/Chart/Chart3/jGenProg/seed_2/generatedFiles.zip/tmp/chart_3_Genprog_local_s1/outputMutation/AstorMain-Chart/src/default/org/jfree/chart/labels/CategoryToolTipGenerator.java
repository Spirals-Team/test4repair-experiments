package org.jfree.chart.labels;


public interface CategoryToolTipGenerator {
	public java.lang.String generateToolTip(org.jfree.data.category.CategoryDataset dataset, int row, int column);
}

