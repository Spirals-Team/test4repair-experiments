package org.jfree.chart.event;


public class OverlayChangeEvent extends java.util.EventObject {
	public OverlayChangeEvent(java.lang.Object source) {
		super(source);
	}
}

