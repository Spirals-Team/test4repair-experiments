package org.jfree.chart.event;


public interface MarkerChangeListener extends java.util.EventListener {
	public void markerChanged(org.jfree.chart.event.MarkerChangeEvent event);
}

