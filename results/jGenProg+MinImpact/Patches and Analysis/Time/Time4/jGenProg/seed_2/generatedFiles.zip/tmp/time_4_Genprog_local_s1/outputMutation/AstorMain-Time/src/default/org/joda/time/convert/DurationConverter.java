package org.joda.time.convert;


public interface DurationConverter extends org.joda.time.convert.Converter {
	long getDurationMillis(java.lang.Object object);
}

