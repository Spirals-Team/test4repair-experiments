package org.jfree.chart.entity;


public class TickLabelEntity extends org.jfree.chart.entity.ChartEntity implements java.io.Serializable , java.lang.Cloneable {
	private static final long serialVersionUID = 681583956588092095L;

	public TickLabelEntity(java.awt.Shape area ,java.lang.String toolTipText ,java.lang.String urlText) {
		super(area, toolTipText, urlText);
	}
}

