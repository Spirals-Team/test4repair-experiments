package org.jfree.chart.event;


public interface AxisChangeListener extends java.util.EventListener {
	public void axisChanged(org.jfree.chart.event.AxisChangeEvent event);
}

