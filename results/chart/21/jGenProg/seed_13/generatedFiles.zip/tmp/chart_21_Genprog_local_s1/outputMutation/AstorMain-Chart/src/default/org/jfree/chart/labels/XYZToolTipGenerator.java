package org.jfree.chart.labels;


public interface XYZToolTipGenerator extends org.jfree.chart.labels.XYToolTipGenerator {
	public java.lang.String generateToolTip(org.jfree.data.xy.XYZDataset dataset, int series, int item);
}

