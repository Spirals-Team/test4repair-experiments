package org.jfree.chart.ui;


public class Contributor {
	private java.lang.String name;

	private java.lang.String email;

	public Contributor(java.lang.String name ,java.lang.String email) {
		org.jfree.chart.ui.Contributor.this.name = name;
		org.jfree.chart.ui.Contributor.this.email = email;
	}

	public java.lang.String getName() {
		return org.jfree.chart.ui.Contributor.this.name;
	}

	public java.lang.String getEmail() {
		return org.jfree.chart.ui.Contributor.this.email;
	}
}

