package org.jfree.chart.event;


public interface ChartChangeListener extends java.util.EventListener {
	public void chartChanged(org.jfree.chart.event.ChartChangeEvent event);
}

