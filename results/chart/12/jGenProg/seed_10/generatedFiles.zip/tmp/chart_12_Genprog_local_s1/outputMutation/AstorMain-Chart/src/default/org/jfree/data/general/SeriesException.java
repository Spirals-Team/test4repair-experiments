package org.jfree.data.general;


public class SeriesException extends java.lang.RuntimeException implements java.io.Serializable {
	private static final long serialVersionUID = -3667048387550852940L;

	public SeriesException(java.lang.String message) {
		super(message);
	}
}

