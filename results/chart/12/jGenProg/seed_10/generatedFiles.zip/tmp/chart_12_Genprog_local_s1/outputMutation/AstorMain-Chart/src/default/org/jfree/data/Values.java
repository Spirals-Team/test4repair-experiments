package org.jfree.data;


public interface Values {
	public int getItemCount();

	public java.lang.Number getValue(int index);
}

