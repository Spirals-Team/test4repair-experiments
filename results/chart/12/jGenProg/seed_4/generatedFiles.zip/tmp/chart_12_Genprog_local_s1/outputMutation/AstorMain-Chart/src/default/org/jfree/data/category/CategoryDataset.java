package org.jfree.data.category;


public interface CategoryDataset extends org.jfree.data.KeyedValues2D , org.jfree.data.general.Dataset {}

