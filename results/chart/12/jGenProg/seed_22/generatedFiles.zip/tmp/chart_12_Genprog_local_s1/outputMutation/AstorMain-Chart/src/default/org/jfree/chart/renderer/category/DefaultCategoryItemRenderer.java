package org.jfree.chart.renderer.category;


public class DefaultCategoryItemRenderer extends org.jfree.chart.renderer.category.LineAndShapeRenderer implements java.io.Serializable {
	private static final long serialVersionUID = -7793786349384231896L;
}

