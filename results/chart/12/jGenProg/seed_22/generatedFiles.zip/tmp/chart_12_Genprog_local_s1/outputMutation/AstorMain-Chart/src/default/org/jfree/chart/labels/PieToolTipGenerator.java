package org.jfree.chart.labels;


public interface PieToolTipGenerator {
	public java.lang.String generateToolTip(org.jfree.data.general.PieDataset dataset, java.lang.Comparable key);
}

