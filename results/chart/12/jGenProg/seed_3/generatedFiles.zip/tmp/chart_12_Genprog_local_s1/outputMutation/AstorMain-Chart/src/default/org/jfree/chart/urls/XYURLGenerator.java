package org.jfree.chart.urls;


public interface XYURLGenerator {
	public java.lang.String generateURL(org.jfree.data.xy.XYDataset dataset, int series, int item);
}

