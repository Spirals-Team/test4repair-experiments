package org.jfree.data.general;


public interface KeyedValuesDataset extends org.jfree.data.general.PieDataset {}

