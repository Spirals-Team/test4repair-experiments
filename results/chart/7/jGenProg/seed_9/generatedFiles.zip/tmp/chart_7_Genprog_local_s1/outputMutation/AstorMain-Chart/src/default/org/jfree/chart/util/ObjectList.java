package org.jfree.chart.util;


public class ObjectList extends org.jfree.chart.util.AbstractObjectList {
	public ObjectList() {
	}

	public ObjectList(int initialCapacity) {
		super(initialCapacity);
	}

	public java.lang.Object get(int index) {
		return super.get(index);
	}

	public void set(int index, java.lang.Object object) {
		super.set(index, object);
	}

	public int indexOf(java.lang.Object object) {
		return super.indexOf(object);
	}
}

