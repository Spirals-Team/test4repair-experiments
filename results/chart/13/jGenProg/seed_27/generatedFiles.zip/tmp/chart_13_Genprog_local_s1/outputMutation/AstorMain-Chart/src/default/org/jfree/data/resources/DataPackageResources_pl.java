package org.jfree.data.resources;


public class DataPackageResources_pl extends java.util.ListResourceBundle {
	public java.lang.Object[][] getContents() {
		return org.jfree.data.resources.DataPackageResources_pl.CONTENTS;
	}

	private static final java.lang.Object[][] CONTENTS = new java.lang.Object[][]{ new java.lang.Object[]{ "series.default-prefix" , "Serie" } , new java.lang.Object[]{ "categories.default-prefix" , "Kategorie" } };
}

