package org.jfree.chart.labels;


public interface CategorySeriesLabelGenerator {
	public java.lang.String generateLabel(org.jfree.data.category.CategoryDataset dataset, int series);
}

