package org.jfree.chart.labels;


public interface XYItemLabelGenerator {
	public java.lang.String generateLabel(org.jfree.data.xy.XYDataset dataset, int series, int item);
}

