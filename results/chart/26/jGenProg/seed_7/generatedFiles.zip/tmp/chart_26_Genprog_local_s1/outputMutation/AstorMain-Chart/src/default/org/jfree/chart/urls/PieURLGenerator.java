package org.jfree.chart.urls;


public interface PieURLGenerator {
	public java.lang.String generateURL(org.jfree.data.general.PieDataset dataset, java.lang.Comparable key, int pieIndex);
}

