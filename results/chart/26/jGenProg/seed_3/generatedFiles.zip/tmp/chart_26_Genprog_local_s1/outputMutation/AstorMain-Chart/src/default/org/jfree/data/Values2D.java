package org.jfree.data;


public interface Values2D {
	public int getRowCount();

	public int getColumnCount();

	public java.lang.Number getValue(int row, int column);
}

