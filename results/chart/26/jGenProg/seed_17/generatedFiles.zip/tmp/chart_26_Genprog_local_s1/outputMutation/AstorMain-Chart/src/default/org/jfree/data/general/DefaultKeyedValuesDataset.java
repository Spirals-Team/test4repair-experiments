package org.jfree.data.general;


public class DefaultKeyedValuesDataset extends org.jfree.data.general.DefaultPieDataset implements org.jfree.data.general.KeyedValuesDataset {
	private static final long serialVersionUID = 306264413152815781L;
}

