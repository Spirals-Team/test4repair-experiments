package org.jfree.data;


public interface Value {
	public java.lang.Number getValue();
}

