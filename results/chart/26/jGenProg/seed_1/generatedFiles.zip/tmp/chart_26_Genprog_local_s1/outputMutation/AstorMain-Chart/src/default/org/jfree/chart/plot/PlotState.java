package org.jfree.chart.plot;


public class PlotState {
	private java.util.Map sharedAxisStates;

	public PlotState() {
		org.jfree.chart.plot.PlotState.this.sharedAxisStates = new java.util.HashMap();
	}

	public java.util.Map getSharedAxisStates() {
		return org.jfree.chart.plot.PlotState.this.sharedAxisStates;
	}
}

