package org.jfree.chart.urls;


public interface XYZURLGenerator extends org.jfree.chart.urls.XYURLGenerator {
	public java.lang.String generateURL(org.jfree.data.xy.XYZDataset dataset, int series, int item);
}

