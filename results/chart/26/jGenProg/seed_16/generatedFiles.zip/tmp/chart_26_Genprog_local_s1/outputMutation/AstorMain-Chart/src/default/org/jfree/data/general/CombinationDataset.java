package org.jfree.data.general;


public interface CombinationDataset {
	public org.jfree.data.general.SeriesDataset getParent();

	public int[] getMap();
}

