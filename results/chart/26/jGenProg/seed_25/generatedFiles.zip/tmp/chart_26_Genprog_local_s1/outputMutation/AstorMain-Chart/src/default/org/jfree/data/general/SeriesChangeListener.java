package org.jfree.data.general;


public interface SeriesChangeListener extends java.util.EventListener {
	public void seriesChanged(org.jfree.data.general.SeriesChangeEvent event);
}

