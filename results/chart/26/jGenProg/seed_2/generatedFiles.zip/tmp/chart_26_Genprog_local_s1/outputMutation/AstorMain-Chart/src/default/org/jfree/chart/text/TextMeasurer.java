package org.jfree.chart.text;


public interface TextMeasurer {
	public float getStringWidth(java.lang.String text, int start, int end);
}

