package org.jfree.data.general;


public interface KeyedValues2DDataset extends org.jfree.data.category.CategoryDataset {}

