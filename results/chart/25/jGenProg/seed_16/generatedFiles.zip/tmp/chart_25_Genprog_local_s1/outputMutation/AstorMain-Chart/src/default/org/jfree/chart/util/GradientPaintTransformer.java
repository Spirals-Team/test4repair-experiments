package org.jfree.chart.util;


public interface GradientPaintTransformer {
	public java.awt.GradientPaint transform(java.awt.GradientPaint paint, java.awt.Shape target);
}

