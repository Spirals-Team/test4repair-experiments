package org.jfree.chart.editor;


public interface ChartEditorFactory {
	public org.jfree.chart.editor.ChartEditor createEditor(org.jfree.chart.JFreeChart chart);
}

