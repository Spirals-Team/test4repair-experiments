package org.jfree.chart.labels;


public interface CrosshairLabelGenerator {
	public java.lang.String generateLabel(org.jfree.chart.plot.Crosshair crosshair);
}

