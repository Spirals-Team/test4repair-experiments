package org.jfree.data.xy;


public interface SelectableXYDataset {
	public org.jfree.data.xy.XYDatasetSelectionState getSelectionState();
}

