package org.jfree.data.event;


public interface SeriesChangeListener extends java.util.EventListener {
	public void seriesChanged(org.jfree.data.event.SeriesChangeEvent event);
}

