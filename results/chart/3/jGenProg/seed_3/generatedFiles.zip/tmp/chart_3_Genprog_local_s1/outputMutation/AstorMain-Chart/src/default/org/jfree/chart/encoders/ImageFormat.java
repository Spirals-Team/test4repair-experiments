package org.jfree.chart.encoders;


public interface ImageFormat {
	public static java.lang.String PNG = "png";

	public static java.lang.String JPEG = "jpeg";

	public static java.lang.String GIF = "gif";
}

