package org.jfree.chart.editor;


public interface ChartEditor {
	public void updateChart(org.jfree.chart.JFreeChart chart);
}

