package org.jfree.data.resources;


public class DataPackageResources extends java.util.ListResourceBundle {
	public java.lang.Object[][] getContents() {
		return org.jfree.data.resources.DataPackageResources.CONTENTS;
	}

	private static final java.lang.Object[][] CONTENTS = new java.lang.Object[][]{ new java.lang.Object[]{ "series.default-prefix" , "Series" } , new java.lang.Object[]{ "categories.default-prefix" , "Category" } };
}

