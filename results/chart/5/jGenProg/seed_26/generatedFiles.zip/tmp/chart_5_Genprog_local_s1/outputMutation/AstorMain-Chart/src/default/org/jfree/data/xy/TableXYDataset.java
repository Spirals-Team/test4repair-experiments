package org.jfree.data.xy;


public interface TableXYDataset extends org.jfree.data.xy.XYDataset {
	public int getItemCount();
}

