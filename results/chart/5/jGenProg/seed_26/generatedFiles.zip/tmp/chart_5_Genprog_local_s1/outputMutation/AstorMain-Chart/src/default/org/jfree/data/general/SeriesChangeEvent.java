package org.jfree.data.general;


public class SeriesChangeEvent extends java.util.EventObject implements java.io.Serializable {
	private static final long serialVersionUID = 1593866085210089052L;

	public SeriesChangeEvent(java.lang.Object source) {
		super(source);
	}
}

