package org.jfree.data.time;


public interface TimePeriod extends java.lang.Comparable {
	public java.util.Date getStart();

	public java.util.Date getEnd();
}

