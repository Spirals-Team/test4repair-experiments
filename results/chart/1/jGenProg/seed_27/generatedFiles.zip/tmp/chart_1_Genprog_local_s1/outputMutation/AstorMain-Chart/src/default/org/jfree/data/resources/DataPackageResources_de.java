package org.jfree.data.resources;


public class DataPackageResources_de extends java.util.ListResourceBundle {
	public java.lang.Object[][] getContents() {
		return org.jfree.data.resources.DataPackageResources_de.CONTENTS;
	}

	private static final java.lang.Object[][] CONTENTS = new java.lang.Object[][]{ new java.lang.Object[]{ "series.default-prefix" , "Reihen" } , new java.lang.Object[]{ "categories.default-prefix" , "Kategorien" } };
}

