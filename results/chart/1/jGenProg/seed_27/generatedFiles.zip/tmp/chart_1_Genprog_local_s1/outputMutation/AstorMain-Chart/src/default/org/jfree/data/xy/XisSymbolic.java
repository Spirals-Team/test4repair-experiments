package org.jfree.data.xy;


public interface XisSymbolic {
	public java.lang.String[] getXSymbolicValues();

	public java.lang.String getXSymbolicValue(int series, int item);

	public java.lang.String getXSymbolicValue(java.lang.Integer val);
}

