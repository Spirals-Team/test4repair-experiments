package org.jfree.data.xy;


public interface XYRangeInfo {
	public org.jfree.data.Range getRangeBounds(java.util.List visibleSeriesKeys, org.jfree.data.Range xRange, boolean includeInterval);
}

