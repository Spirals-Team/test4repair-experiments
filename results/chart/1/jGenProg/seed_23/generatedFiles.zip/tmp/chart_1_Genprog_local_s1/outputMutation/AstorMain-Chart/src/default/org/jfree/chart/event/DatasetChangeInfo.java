package org.jfree.chart.event;


public class DatasetChangeInfo {}

