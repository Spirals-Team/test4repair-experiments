package org.jfree.chart;


public interface ChartTheme {
	public void apply(org.jfree.chart.JFreeChart chart);
}

