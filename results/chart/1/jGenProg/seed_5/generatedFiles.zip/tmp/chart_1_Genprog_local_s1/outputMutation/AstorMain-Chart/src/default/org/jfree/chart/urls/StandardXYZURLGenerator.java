package org.jfree.chart.urls;


public class StandardXYZURLGenerator extends org.jfree.chart.urls.StandardXYURLGenerator implements org.jfree.chart.urls.XYZURLGenerator {
	public java.lang.String generateURL(org.jfree.data.xy.XYZDataset dataset, int series, int item) {
		return super.generateURL(dataset, series, item);
	}
}

