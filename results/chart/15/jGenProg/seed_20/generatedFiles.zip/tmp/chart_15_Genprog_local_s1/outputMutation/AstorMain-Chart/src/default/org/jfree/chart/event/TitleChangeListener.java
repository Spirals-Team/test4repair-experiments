package org.jfree.chart.event;


public interface TitleChangeListener extends java.util.EventListener {
	public void titleChanged(org.jfree.chart.event.TitleChangeEvent event);
}

