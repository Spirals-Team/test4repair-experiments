package org.jfree.chart;


public interface ChartMouseListener extends java.util.EventListener {
	void chartMouseClicked(org.jfree.chart.ChartMouseEvent event);

	void chartMouseMoved(org.jfree.chart.ChartMouseEvent event);
}

