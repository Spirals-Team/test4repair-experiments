package org.jfree.data.general;


public interface KeyedValueDataset extends org.jfree.data.KeyedValue , org.jfree.data.general.Dataset {}

