package org.jfree.chart.resources;


public class JFreeChartResources extends java.util.ListResourceBundle {
	public java.lang.Object[][] getContents() {
		return org.jfree.chart.resources.JFreeChartResources.CONTENTS;
	}

	private static final java.lang.Object[][] CONTENTS = new java.lang.Object[][]{ new java.lang.Object[]{ "project.name" , "JFreeChart" } , new java.lang.Object[]{ "project.version" , "1.2.0-pre" } , new java.lang.Object[]{ "project.info" , "http://www.jfree.org/jfreechart/index.html" } , new java.lang.Object[]{ "project.copyright" , "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" } };
}

