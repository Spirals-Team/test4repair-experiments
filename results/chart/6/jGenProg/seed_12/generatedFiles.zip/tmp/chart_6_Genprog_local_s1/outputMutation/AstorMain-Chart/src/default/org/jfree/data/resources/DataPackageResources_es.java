package org.jfree.data.resources;


public class DataPackageResources_es extends java.util.ListResourceBundle {
	public java.lang.Object[][] getContents() {
		return org.jfree.data.resources.DataPackageResources_es.CONTENTS;
	}

	private static final java.lang.Object[][] CONTENTS = new java.lang.Object[][]{ new java.lang.Object[]{ "series.default-prefix" , "Series" } , new java.lang.Object[]{ "categories.default-prefix" , "Categor?a" } };
}

