package org.jfree.data.xy;


public interface YisSymbolic {
	public java.lang.String[] getYSymbolicValues();

	public java.lang.String getYSymbolicValue(int series, int item);

	public java.lang.String getYSymbolicValue(java.lang.Integer val);
}

