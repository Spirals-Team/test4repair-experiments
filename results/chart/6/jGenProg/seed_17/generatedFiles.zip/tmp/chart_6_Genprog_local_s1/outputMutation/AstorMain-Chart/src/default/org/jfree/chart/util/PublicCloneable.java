package org.jfree.chart.util;


public interface PublicCloneable extends java.lang.Cloneable {
	public java.lang.Object clone() throws java.lang.CloneNotSupportedException;
}

