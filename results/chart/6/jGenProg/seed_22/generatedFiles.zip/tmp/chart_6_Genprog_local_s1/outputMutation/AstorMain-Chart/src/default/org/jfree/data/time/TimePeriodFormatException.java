package org.jfree.data.time;


public class TimePeriodFormatException extends java.lang.IllegalArgumentException {
	public TimePeriodFormatException(java.lang.String message) {
		super(message);
	}
}

