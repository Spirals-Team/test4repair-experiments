package org.jfree.data.xy;


public interface XYZDataset extends org.jfree.data.xy.XYDataset {
	public java.lang.Number getZ(int series, int item);

	public double getZValue(int series, int item);
}

