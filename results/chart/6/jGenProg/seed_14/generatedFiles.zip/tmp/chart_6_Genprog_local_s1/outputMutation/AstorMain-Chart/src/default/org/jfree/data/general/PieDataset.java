package org.jfree.data.general;


public interface PieDataset extends org.jfree.data.KeyedValues , org.jfree.data.general.Dataset {}

