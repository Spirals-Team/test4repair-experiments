package org.jfree.chart.imagemap;


public interface URLTagFragmentGenerator {
	public java.lang.String generateURLFragment(java.lang.String urlText);
}

