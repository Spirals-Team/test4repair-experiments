package org.jfree.chart.labels;


public interface XYSeriesLabelGenerator {
	public java.lang.String generateLabel(org.jfree.data.xy.XYDataset dataset, int series);
}

