package org.jfree.chart.plot.dial;


public interface DialFrame extends org.jfree.chart.plot.dial.DialLayer {
	public java.awt.Shape getWindow(java.awt.geom.Rectangle2D frame);
}

