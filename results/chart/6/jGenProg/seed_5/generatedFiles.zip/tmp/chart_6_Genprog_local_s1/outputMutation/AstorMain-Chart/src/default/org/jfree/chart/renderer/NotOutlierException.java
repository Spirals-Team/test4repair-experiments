package org.jfree.chart.renderer;


public class NotOutlierException extends java.lang.Exception {
	public NotOutlierException(java.lang.String message) {
		super(message);
	}
}

