package org.jfree.chart.labels;


public interface XYToolTipGenerator {
	public java.lang.String generateToolTip(org.jfree.data.xy.XYDataset dataset, int series, int item);
}

