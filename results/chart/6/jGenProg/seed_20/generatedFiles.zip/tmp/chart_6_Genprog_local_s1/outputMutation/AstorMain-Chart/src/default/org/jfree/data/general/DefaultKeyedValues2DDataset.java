package org.jfree.data.general;


public class DefaultKeyedValues2DDataset extends org.jfree.data.category.DefaultCategoryDataset implements java.io.Serializable , org.jfree.data.general.KeyedValues2DDataset {
	private static final long serialVersionUID = 4288210771905990424L;
}

