package org.jfree.chart.urls;


public interface CategoryURLGenerator {
	public java.lang.String generateURL(org.jfree.data.category.CategoryDataset data, int series, int category);
}

